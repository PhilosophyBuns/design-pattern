create PROCEDURE pColMdf(sTable1 VARCHAR2,sTable2 VARCHAR2,nMdf NUMBER,nModified OUT NUMBER)
AS
	sColName 	VARCHAR2(31);
 	sColType 	VARCHAR2(107);
 	nWidth		NUMBER;
 	nPrecision	NUMBER;
 	nScale		NUMBER;
 	sNull		VARCHAR(20);
 	sSql		VARCHAR2(4096);
 	sFields		VARCHAR2(4096);
 	sWidth		VARCHAR2(100);
 	CURSOR CSR_ADD IS
    	SELECT T1.CNAME,T1.COLTYPE,T1.WIDTH,T1.PRECISION,T1.SCALE,T1.NULLS
    		FROM (
    			SELECT CNAME,COLTYPE,WIDTH,PRECISION,SCALE,NULLS,COLNO
    			FROM COL
    			WHERE TNAME = sTable1
    		) T1,(
    			SELECT CNAME
    			FROM COL
    			WHERE TNAME = sTable2
    		) T2
    	WHERE T1.CNAME = T2.CNAME(+)
    		AND T2.CNAME IS NULL
    	ORDER BY T1.COLNO;
    CURSOR CSR_MDF IS
    	SELECT T1.CNAME,T1.COLTYPE,T1.WIDTH,T1.PRECISION,T1.SCALE,T1.NULLS
    		FROM (
    			SELECT CNAME,COLTYPE,WIDTH,NVL(PRECISION,0) PRECISION,NVL(SCALE,0) SCALE,NULLS,COLNO
    			FROM COL
    			WHERE TNAME = sTable1
    		) T1,(
    			SELECT CNAME,COLTYPE,WIDTH,NVL(PRECISION,0) PRECISION,NVL(SCALE,0) SCALE
    			FROM COL
    			WHERE TNAME = sTable2
    		) T2
    	WHERE T1.CNAME = T2.CNAME
    		AND (
    			T1.COLTYPE != T2.COLTYPE		OR
    			T1.WIDTH != T2.WIDTH			OR
    			T1.PRECISION != T2.PRECISION	OR
    			T1.SCALE != T2.SCALE
    		)
    	ORDER BY T1.COLNO;
    CURSOR CSR_TBL IS
    	SELECT CNAME,COLTYPE,WIDTH,NVL(PRECISION,0) PRECISION,NVL(SCALE,0) SCALE,NULLS
    		FROM COL
    		WHERE TNAME = sTable1
    		ORDER BY COLNO;
BEGIN
	sSql := '';
	nModified := 0;
    sFields := '';
    IF nMdf = 1 THEN
    	OPEN CSR_TBL;
    ELSIF nMdf = 2 THEN
    	OPEN CSR_ADD;
    ELSE
    	OPEN CSR_MDF;
    END IF;
    LOOP
    	sColName := '';
    	sColType := '';
    	nWidth := 0;
    	nPrecision := 0;
    	nScale := 0;
    	sNull := '';
    	IF nMdf = 1 THEN
    		FETCH CSR_TBL INTO sColName,sColType,nWidth,nPrecision,nScale,sNull;
    		EXIT WHEN CSR_TBL%NOTFOUND;
    	ELSIF nMdf = 2 THEN
    		FETCH CSR_ADD INTO sColName,sColType,nWidth,nPrecision,nScale,sNull;
    		EXIT WHEN CSR_ADD%NOTFOUND;
    	ELSE
    		FETCH CSR_MDF INTO sColName,sColType,nWidth,nPrecision,nScale,sNull;
    		EXIT WHEN CSR_MDF%NOTFOUND;
    	END IF;
    	sColName := TRIM(sColName);
    	sColType := TRIM(sColType);
    	sNull := TRIM(sNull);
    	IF nModified = 1 THEN
    		sFields := sFields || ' , ';
		END IF;
    	IF sColType = 'DATE' THEN
    		sWidth := '';
    	ELSE
    		IF TRIM(sColType) = 'NUMBER' THEN
        		sWidth := '(' || TO_CHAR(nPrecision) || ',' || TO_CHAR(nScale) || ')';
        	ELSE
        		sWidth := '(' || TO_CHAR(nWidth) || ')';
        	END IF;
		END IF;
		IF nMdf != 1 THEN
			sNull := '';
		END IF;
    	sFields := sFields || sColName || ' ' || sColType || sWidth || ' ' || sNull;
    	nModified := 1;
    END LOOP;
    IF nMdf = 1 THEN
		CLOSE CSR_TBL;
		sSql := 'CREATE TABLE ' || sTable2 || '(' || sFields || ')';
	ELSIF nMdf = 2 THEN
		CLOSE CSR_ADD;
		sSql := 'ALTER TABLE ' || sTable2 || ' ADD (' || sFields || ')';
	ELSE
		CLOSE CSR_MDF;
		sSql := 'ALTER TABLE ' || sTable2 || ' MODIFY (' || sFields || ')';
	END IF;
    IF nModified = 1 THEN
		EXECUTE IMMEDIATE sSql;
	END IF;
END pColMdf;
/

