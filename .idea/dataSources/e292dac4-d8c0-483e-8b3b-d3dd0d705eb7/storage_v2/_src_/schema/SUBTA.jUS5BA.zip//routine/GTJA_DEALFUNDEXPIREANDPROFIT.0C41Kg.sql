create procedure gtja_dealFundExpireAndProfit is
  begin
       for a in (select index_name from all_indexes where owner='TRADE') LOOP
           v_sql := 'analyze index ' ||a.index_name || ' validate structure';
           execute immediate v_sql;
           insert into monitorindex
           (INDEX_NAME, DEL_LF_ROWS,  iF_ROWS,  RATE)
           select name,  DEL_LF_ROWS,  LF_ROWS, round(del_lf_rows *100/(del_lf_rows+lf_rows+0.01),2)
            from index_stats;
        END loop;
 END analyzeindex;


 select *  from tbusinflag
select *from tconfirm tt where tt.c_outbusinflag=024 and tt.c_fundacco='952028' order by d_cdate desc
/

