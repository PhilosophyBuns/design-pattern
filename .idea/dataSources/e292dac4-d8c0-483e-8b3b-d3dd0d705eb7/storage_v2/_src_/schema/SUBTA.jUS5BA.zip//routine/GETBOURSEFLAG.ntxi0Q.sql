create function GetBourseFlag(sFundAcco in varchar2)
return char
is
  ch          char(1);
  vcFundacco  varchar2(12);
begin
    vcFundacco := trim(sFundAcco);
    ch := '';
    if length(vcFundacco)=12 then
        ch := '9';
    elsif length(vcFundacco)=10 then
    begin
        if  (vcFundacco = 'WWWWWWWWWW') or
            (vcFundacco = 'LLLLLLLLLL') or
            (substr(vcFundacco, 1, 2) = '**') then
            ch := '1';
        elsif( substr(vcFundacco,1,1) >= '0') and (substr(vcFundacco,1,1)<= '9') then
            ch := '1';
        else
            ch := '0';
        end if;
    end;
    end if;
    return ch;
end GetBourseFlag;


/

