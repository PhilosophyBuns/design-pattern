create package pkg_Openfund_BuyRedeemSum
is
  type hash_agency       is table of varchar2(8)  index by varchar2(3);
  type hash_fundagency   is table of date         index by varchar2(9);
  type hash_netvalue     is table of number(7,4)  index by varchar2(6);
  type hash_exchangerate is table of number(14,10)  index by varchar2(6);
  TYPE hash_lastshares   IS TABLE OF NUMBER(16,2) INDEX BY VARCHAR2(6);
  TYPE hash_lastasset    IS TABLE OF NUMBER(16,2) INDEX BY VARCHAR2(6);
  TYPE hash_holddate     IS TABLE OF VARCHAR2(8)  INDEX BY VARCHAR2(6);
  type hash_agencytype   is table of varchar2(1)  index by varchar2(3);
  type hash_fundprop     is table of varchar2(1)  index by varchar2(6);

  v_hash_agency        hash_agency;
  v_hash_fundagency    hash_fundagency;
  v_hash_netvalue      hash_netvalue;
  v_hash_lastshares    hash_lastshares;
  v_hash_lastasset     hash_lastasset;
  v_hash_holddate      hash_holddate;
  v_hash_agencytype    hash_agencytype;
  v_hash_fundprop      hash_fundprop;
  v_hash_exchangerate  hash_exchangerate;

  function  func_agency_cdate(p_agency in varchar2) return varchar2;
  function  func_fundagency_cdate(p_fundagency in varchar2) return date;
  function  func_get_netvalue(p_fundcode in varchar2) return number;
  function  func_get_exchangerate(p_fundcode in varchar2) return number;
  FUNCTION  func_get_lastshares(p_fundcode IN VARCHAR2) RETURN NUMBER;
  FUNCTION  func_get_lastasset(p_fundcode IN VARCHAR2) RETURN NUMBER;
  FUNCTION  func_get_holddate(p_fundcode IN VARCHAR2) RETURN VARCHAR2;
  function  func_get_agencytype(p_agency in varchar2) return varchar2;
  function  func_get_fundprop(p_fundcode in varchar2) return varchar2;

  procedure proc_summary(p_ddate in varchar2,p_fundcode in varchar2 default '',p_ifonlyopenfund in varchar2 default 'Y');
end;

/

