create PROCEDURE STOREINDEX(accocount in integer,reqcount in integer)
AS
  V_SQL VARCHAR2(1000);
  v_indexname varchar2(40);
  v_firstsql integer;
  v_tablename varchar2(1000);
BEGIN
  if accocount > 50000000 and reqcount < 50000000 then
    v_tablename := 'TACCOREQUEST,TCUSTOMERINFO,TACCONET,TMULTITRADEACCO,TACCOINFO';
  ELSIF accocount < 50000000 and reqcount > 50000000 then
    v_tablename := 'TREQUEST,TCONFIRM,TCONFIRMDETAIL,TSHAREDETAIL,TSTATICSHARES,TSHARECURRENTS';
  ELSIF accocount > 50000000 and reqcount > 50000000 then
    v_tablename := 'TREQUEST,TCONFIRM,TCONFIRMDETAIL,TSHAREDETAIL,TSTATICSHARES,TSHARECURRENTS,TACCOREQUEST,TCUSTOMERINFO,TACCONET,TMULTITRADEACCO,TACCOINFO';
  else
    RETURN;
  end if;

  v_firstsql := 0;
  for c in (select 'drop table '|| table_name DROPSQL from user_tables where table_name = 'TCREATEINDEXSQL')
  LOOP
    EXECUTE IMMEDIATE C.DROPSQL;
  END LOOP;
  EXECUTE IMMEDIATE 'CREATE TABLE TCREATEINDEXSQL(indexname varchar2(1000),INDEXSQL VARCHAR2(1000))';

  FOR C IN (
  select a.INDEX_NAME,a.TABLE_NAME,a.UNIQUENESS,b.COLUMN_NAME from user_indexes a,user_ind_columns b
   where a.TABLE_NAME = b.TABLE_NAME
     and a.INDEX_NAME = b.INDEX_NAME
     and INSTR(V_TABLENAME,a.TABLE_NAME) > 0
   order by B.INDEX_NAME,b.COLUMN_POSITION)
  LOOP
    if nvl(v_indexname,'*') <> c.INDEX_NAME then
      if v_firstsql = 0 then
        v_sql := 'create ' || case when c.uniqueness = 'UNIQUE' then 'unique ' else '' end || 'index '||c.index_name || ' on '||c.table_name||'('||c.column_name;
        v_firstsql := 1;
      else
        v_sql := v_sql || ')';
        execute immediate 'insert into TCREATEINDEXSQL(indexname,indexsql) values('''||v_indexname||''','''||v_sql||''')';
        v_sql := 'create ' || case when c.uniqueness = 'UNIQUE' then 'unique ' else '' end || 'index '||c.index_name || ' on '||c.table_name||'('||c.column_name;
      end if;
      v_indexname := c.INDEX_NAME;
    else
      v_sql := v_sql || ',' || c.column_name;
    end if;
  END LOOP;

  if v_firstsql = 1 then
    v_sql := v_sql||')';
  end if;

  execute immediate 'insert into TCREATEINDEXSQL(indexname,indexsql) values('''||v_indexname||''','''||v_sql||''')';
  commit;

  for c1 in (select 'drop index '||index_name dropindexsql from user_indexes a
              where INSTR(V_TABLENAME,a.TABLE_NAME) > 0)
  loop
    execute immediate c1.dropindexsql;
  end loop;

END;



/

