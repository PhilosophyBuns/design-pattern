create view VTAILRATIO as
  select c_fundcode, c_agencyno, c_flag,  c_updateflag,
       f_sharemin, f_sharemax, f_ratio,f_floatratio, d_begindate,c_enableExternalratio,
       last_value(d_enddate)over(partition by c_fundcode, c_agencyno, d_begindate
                                     order by d_enddate
                                      rows between unbounded preceding
                                               and unbounded following) d_enddate
  from (select c_fundcode, c_agencyno, c_flag,  c_updateflag,
               f_sharemin, f_sharemax, f_ratio, f_floatratio, d_begindate,c_enableExternalratio,
               nvl(lead(d_begindate)over(partition by c_fundcode, c_agencyno
                                             order by d_begindate, f_sharemin),
               to_date('20991231', 'yyyymmdd')) d_enddate
          from ttailratio)
/

