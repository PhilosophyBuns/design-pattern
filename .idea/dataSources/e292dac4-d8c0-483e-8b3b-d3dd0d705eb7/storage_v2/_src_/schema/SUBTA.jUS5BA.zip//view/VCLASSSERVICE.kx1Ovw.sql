create view VCLASSSERVICE as
  select c_fundcode, c_shareclass, c_agencyno, c_updateflag,
       f_sharemin, f_sharemax,   f_ratio,    f_serviceratio, d_begindate,
       last_value(d_enddate) over(partition by c_fundcode, c_shareclass, c_agencyno, d_begindate
                                      order by d_enddate rows between unbounded preceding
                                                                  and unbounded following) d_enddate
  from (select c_fundcode, c_shareclass, c_agencyno, c_updateflag,
               f_sharemin, f_sharemax,   f_ratio,    f_serviceratio, d_begindate,
               nvl(lead(d_begindate) over(partition by c_fundcode, c_shareclass, c_agencyno
                                              order by d_begindate, f_sharemin),
               to_date('20991231', 'yyyymmdd')) d_enddate
          from tclassservice)

/

