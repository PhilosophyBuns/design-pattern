create procedure restoreindex
as
  type c_cursor is ref cursor;
  c c_cursor;
  v_indexsql varchar2(1000);
  v_count  integer;
begin
  execute immediate 'SELECT COUNT(*) from user_tables where table_name = ''TCREATEINDEXSQL''' into v_count;
  if v_count = 0 then
    RETURN ;
  end if;

  open c for 'select indexsql||'' nologging parallel 4'' from tcreateindexsql';
  loop
    fetch c into v_indexsql;
    exit when c%notfound;
    if (v_indexsql is not null) and (v_indexsql <> ' nologging parallel 4') then
      execute immediate v_indexsql;
    end if;
  end loop;
  close c;
  open c for 'select ''alter index ''||indexname||'' noparallel'' alterindex from tcreateindexsql';
  loop
    fetch c into v_indexsql;
    exit when c%notfound;
    if (v_indexsql is not null ) and (v_indexsql <> 'alter index  noparallel' )then
      execute immediate v_indexsql;
    end if;
  end loop;
  close c;
  execute immediate 'drop table tcreateindexsql';
end;


/

