create view ZDTA_ZX as
  select  to_char(d_cdate,'yyyymmdd') c_date,
        c_custname ,
       c_fundacco ,
       c_tradeacco ,
       c_businname , /*s.f_realshares,*/
       c_fundcode  ,
       f_confirmbalance,
 f_confirmshares from
(select  s.d_cdate,
        o.c_custname ,
       s.c_fundacco ,
       s.c_tradeacco ,
       e.c_businname , /*s.f_realshares,*/
       s.c_fundcode  ,
       s.f_confirmbalance ,
 s.f_confirmshares
  from subta.tcustomerinfo o, subta.tconfirm s, subta.tbusinchangeout e
 where o.c_custno=s.c_fundacco and (s.c_netno='710' /*or substr(s.c_tradeacco,4,4)='7777'*/)
 and s.d_cdate=to_date(to_char(sysdate-1, 'YYYY-MM-DD'),'YYYY-MM-DD') and s.c_outbusinflag=e.c_requestflag and s.C_BUSINFLAG = e.c_businflag and
 (o.c_custname='国泰君安证券股份有限公司' or o.c_custname='天津中盛海天投资有限公司' or  instr(o.c_custname,'定向')>0
  --or o.c_custname in( select a.vc_fund_name from trade.tfundinfo@O32.REGRESS.RDBMS.DEV.US.ORACLE.COM a)
   )
 union
 select  s.d_cdate,
        o.c_custname ,
       s.c_fundacco ,
       s.c_tradeacco ,
       '分红' , /*s.f_realshares,*/
       s.c_fundcode  ,
     s.f_totalshare,
     s.f_totalprofit
  from subta.tcustomerinfo o, subta.TDIVIDENDDETAIL s
 where o.c_custno=s.c_fundacco and (s.c_netno='710' /*or substr(s.c_tradeacco,4,4)='7777'*/)
 /*and s.d_cdate=to_date(to_char(sysdate-1, 'YYYY-MM-DD'),'YYYY-MM-DD')*/ and
 (o.c_custname='国泰君安证券股份有限公司' or o.c_custname='天津中盛海天投资有限公司' or  instr(o.c_custname,'定向')>0
 --or o.c_custname in( select a.vc_fund_name from trade.tfundinfo@O32.REGRESS.RDBMS.DEV.US.ORACLE.COM a)
 )
 )
/

