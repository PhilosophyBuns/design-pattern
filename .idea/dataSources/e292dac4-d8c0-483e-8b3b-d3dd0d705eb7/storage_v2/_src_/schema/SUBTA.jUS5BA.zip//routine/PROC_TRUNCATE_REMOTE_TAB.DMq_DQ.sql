create procedure proc_truncate_remote_tab(p_tname in varchar2) as
BEGIN
     if p_tname in ('taccorequest_today' ,'trequest_today') then
      EXECUTE IMMEDIATE 'TRUNCATE TABLE ' || p_tname;
      end if;
EXCEPTION
    WHEN OTHERS THEN
          raise_application_error(-20001,SQLERRM);
  end;


/

