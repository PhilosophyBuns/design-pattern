create FUNCTION GetSubTASpecialMonetary RETURN VARCHAR2
/*author: jiangzj
  *   date: 2012-06-11
  * Example: SELECT GetSubTASpecialMonetary() FROM dual d
  *
  *   date: 2012-07-26
  *    add AutoPairProduct
  *   date: 2012-10-29
  *    add NegotiateProduct
  *   date: 2012-12-13
  *    add MoneyMarket
  *   date: 2013-12-13
  *   use cursor not SYS_CONNECT_BY_PATH
  *   date: 2014-05-20
  *    add UnScheduledProduct
  *   date: 2014-06-18
  *    add FastDeliveryProduct
  *   date: 2014-09-12
  *    add EqualQuitProduct
  *   date: 2016-01-07
  *    add HoldingPeriodIncomeRatio
  *   date: 2017-11-17
  *    add RateByShareDetail
  */
 IS
  vcResult                VARCHAR2(4000) := '';
  vcOpenDepositProduct    tsysparameter.c_value%TYPE;
  vcOpenShortCycleFinance tsysparameter.c_value%TYPE;
  vcOpenAutoPairProduct   tsysparameter.c_value%TYPE;
  vcOpenNegotiateProduct  tsysparameter.c_value%TYPE;
  vcOpenMoneyMarket       tsysparameter.c_value%TYPE;
  vcOpenUnScheduledProduct tsysparameter.c_value%TYPE;
  vcOpenFastDeliveryProduct tsysparameter.c_value%TYPE;
  vcEqualQuitProduct      tsysparameter.c_value%TYPE;
  vcHoldPeriodIncomeRatio tsysparameter.c_value%TYPE;
  vcRateByShareDetail     tsysparameter.c_value%TYPE;
  vdSysCfmDate            DATE;
BEGIN
  --1 get system params
  SELECT /*+ ALL_ROWS INDEX(T ISYSPARAMETER) */
         NVL(MAX(CASE WHEN t.c_item = 'DepositProduct'              THEN TRIM(t.c_value) ELSE NULL END), '0') c_DepositProduct,
         NVL(MAX(CASE WHEN t.c_item = 'ShortCycleFinance'           THEN TRIM(t.c_value) ELSE NULL END), '0') c_ShortCycleFinance,
         NVL(MAX(CASE WHEN t.c_item = 'AutoPairProduct'             THEN TRIM(t.c_value) ELSE NULL END), '0') c_AutoPairProduct,
         NVL(MAX(CASE WHEN t.c_item = 'NegotiateProduct'            THEN TRIM(t.c_value) ELSE NULL END), '0') c_NegotiateProduct,
         NVL(MAX(CASE WHEN t.c_item = 'MoneyMarket'                 THEN TRIM(t.c_value) ELSE NULL END), '0') c_MoneyMarket,
         NVL(MAX(CASE WHEN t.c_item = 'UnScheduledProduct'          THEN TRIM(t.c_value) ELSE NULL END), '0') c_UnScheduledProduct,
         NVL(MAX(CASE WHEN t.c_item = 'FastDeliveryProduct'         THEN TRIM(t.c_value) ELSE NULL END), '0') c_FastDeliveryProduct,
         NVL(MAX(CASE WHEN t.c_item = 'EqualQuitProduct'            THEN TRIM(t.c_value) ELSE NULL END), '0') c_EqualQuitProduct,
         NVL(MAX(CASE WHEN t.c_item = 'HoldingPeriodIncomeRatio'    THEN TRIM(t.c_value) ELSE NULL END), '0') c_HoldingPeriodIncomeRatio,
         NVL(MAX(CASE WHEN t.c_item = 'RateByShareDetail'           THEN TRIM(t.c_value) ELSE NULL END), '0') c_RateByShareDetail
    INTO vcOpenDepositProduct,
         vcOpenShortCycleFinance,
         vcOpenAutoPairProduct,
         vcOpenNegotiateProduct,
         vcOpenMoneyMarket,
         vcOpenUnScheduledProduct,
         vcOpenFastDeliveryProduct,
         vcEqualQuitProduct,
         vcHoldPeriodIncomeRatio,
         vcRateByShareDetail
    FROM tsysparameter t
   WHERE t.c_item IN ('DepositProduct',             'ShortCycleFinance',
                      'AutoPairProduct',            'NegotiateProduct',
                      'MoneyMarket',                'UnScheduledProduct',
                      'FastDeliveryProduct',        'EqualQuitProduct',
                      'HoldingPeriodIncomeRatio',   'RateByShareDetail');

  SELECT /*+ ALL_ROWS INDEX(T ISYSPARAMETER) */
         TO_DATE(TRIM(t.c_value), 'YYYYMMDD') c_value
    INTO vdSysCfmDate
    FROM tsysparameter t
   WHERE ROWNUM = 1
     AND t.c_item = 'SysDate';


  --2 query result
  FOR cur IN (SELECT i.c_fundcode
                FROM (SELECT t.c_fundcode
                        FROM tqsspecialproduct t
                       WHERE (vcOpenDepositProduct = '1' AND t.c_producttype = '0')
                          OR (vcOpenAutoPairProduct = '1' AND t.c_producttype = '3')
                          OR (vcOpenNegotiateProduct = '1' AND t.c_producttype = '4')
                          OR (vcOpenMoneyMarket = '1' AND t.c_producttype = '5')
                          OR (vcOpenUnScheduledProduct = '1' AND t.c_producttype = 'A')
                          OR (vcOpenFastDeliveryProduct = '1' AND t.c_producttype = 'B')
                          OR (vcHoldPeriodIncomeRatio = '1' AND t.c_producttype = 'E')
                          OR (vcRateByShareDetail = '1' AND t.c_producttype = 'H')
                      UNION
                      SELECT t.c_fundcode
                        FROM tshortcyclefinance t
                       WHERE vcOpenShortCycleFinance = '1'
                      union
                      select t.c_fundcode
                        from tEqualQuitScheme t
                       where vcEqualQuitProduct = '1') i,
                     tfundinfo fi
               WHERE i.c_fundcode = fi.c_fundcode
                 AND (      nvl(fi.c_fundstatus, '0') not in ('6','9')
                        OR (    nvl(fi.c_fundstatus, '0') in ('6','9')
                            AND nvl(fi.d_failuedate, vdSysCfmDate) >= vdSysCfmDate)
                     )
               ORDER BY i.c_fundcode) LOOP
    vcResult := vcResult || cur.c_fundcode || ',';
  END LOOP;

  IF (TRIM(vcResult) IS NULL) THEN
    vcResult := '######';
  ELSE
    vcResult := SUBSTR(vcResult, 1, LENGTH(vcResult) - 1);
  END IF;

  --3 return
  RETURN vcResult;
END;

/

