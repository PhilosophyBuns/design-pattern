create function GetKJFundCode(aParamFundCode in varchar2)
return varchar2
is
    aFundCode varchar2(6);
begin
    aFundCode := rtrim(aParamFundCode);

    if aFundCode='519599' then
        return '519999';
    end if;
    if aFundCode='519598' then
        return '519998';
    end if;

    if (aFundCode='940028') or (aFundCode='940038') then
        return '940018';
    end if;

    if (aFundCode='519512') or (aFundCode='519513') or (aFundCode='519521') or (aFundCode='519522') or (aFundCode='519523') then
        return '519511';
    end if;

    return aFundCode;
end GetKJFundCode;


/

