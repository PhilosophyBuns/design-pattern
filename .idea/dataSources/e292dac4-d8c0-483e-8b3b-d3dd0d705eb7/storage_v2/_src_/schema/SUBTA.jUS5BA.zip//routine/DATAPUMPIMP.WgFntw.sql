create procedure DataPumpImp
(
  p_backupfile varchar2,
  p_logfile  varchar2,
  p_backupdir varchar2,
  p_logdir varchar,
  p_job_name     varchar2,
  p_app_user varchar2 := '', --应用程序库
  p_from_user  varchar2 := '' --从一个用户恢复到当前存储过程所在的用户时，需要指名出的用户的用户名
)
is
  v_filehandle utl_file.file_type;
  v_job_handle  pls_integer;
  v_job_state   varchar2(20);
  v_remove_Error integer;
  v_app_user varchar2(50);
  v_from_user varchar2(50);
  v_to_user varchar2(50);
  v_cur_user varchar2(50);
  v_has_datapumpimp integer;/*是否存在有DataPumpImp的存储过程*/
begin

    /*先打开看下 备份文件是否存在*/
    v_filehandle := utl_file.fopen(p_backupdir,p_backupfile,'r');
    utl_file.fclose(v_filehandle);

    select username into v_cur_user from user_users;

    if p_from_user = '' or p_from_user is null then
      v_from_user := upper(v_cur_user);
    else
      v_from_user := upper(p_from_user);
    end if;


    v_to_user := upper(v_cur_user);

    if p_app_user = '' or p_app_user is null then
      v_app_user := upper(v_cur_user);
    else
      v_app_user := upper(p_app_user);
    end if;

    DBMS_OUTPUT.put_line(p_backupfile||';'||p_logfile||';'||p_backupdir||';'||p_logdir||';'||p_job_name||';'||p_from_user||';'||p_app_user);
    dbms_output.put_line(v_cur_user||';'||v_from_user||';'||v_to_user||';'||v_app_user);

    begin
      utl_file.fremove(p_logdir,p_logfile);
    exception when others then
      v_remove_Error := 1;
      dbms_output.put_line('remove logfile failed');
    end;

    v_has_datapumpimp := 0;

    /*先把sequence 存储过程 等drop掉*/
    for t in (select a.OBJECT_NAME,a.OBJECT_TYPE
                from user_objects a
               where object_type in ('PROCEDURE','FUNCTION','PACKAGE','PACKAGE BODY','VIEW','SEQUENCE'))
    loop

      dbms_output.put_line('OBJECT_NAME='||t.object_name||'OBJECT_TYPE'||t.object_type);

      if t.object_name = 'DATAPUMPIMP' then
        v_has_datapumpimp := 1;
      end if;


      if t.object_type = 'PROCEDURE' and t.object_name <> 'DATAPUMPIMP' then
        begin
          dbms_output.put_line('drop procedure ' || t.object_name);
          execute immediate 'drop procedure ' || t.object_name;
        exception when others then
          v_remove_Error := 1;
          dbms_output.put_line('drop procedure failed');
        end;
      end if;

      if t.object_type = 'FUNCTION' then
        begin
          dbms_output.put_line('drop function ' || t.object_name);
          execute immediate 'drop function ' || t.object_name;
        exception when others then
          v_remove_Error := 1;
          dbms_output.put_line('drop function failed');
        end;
      end if;

      if t.object_type = 'PACKAGE' then
        begin
          dbms_output.put_line('drop package ' || t.object_name);
          execute immediate 'drop package ' || t.object_name;
        exception when others then
          v_remove_Error := 1;
          dbms_output.put_line('drop package failed');
        end;
      end if;

      if t.object_name = 'PACKAGE BODY' then
        begin
          dbms_output.put_line('drop package ' || t.object_name);
          execute immediate 'drop package ' || t.object_name;
        exception when others then
          v_remove_Error := 1;
          dbms_output.put_line('drop package failed');
        end;
      end if;

      if t.object_type = 'VIEW' then
        begin
          dbms_output.put_line('drop view ' || t.object_name);
          execute immediate 'drop view ' || t.object_name;
        exception when others then
          v_remove_Error := 1;
          dbms_output.put_line('drop view failed');
        end;
      end if;

      if t.object_type = 'SEQUENCE' then
        begin
          dbms_output.put_line('drop sequence ' || t.object_name);
          execute immediate 'drop sequence ' || t.object_name;
        exception when others then
          v_remove_Error := 1;
          dbms_output.put_line('drop sequence failed');
        end;
      end if;

    end loop;

    begin
    v_job_handle := dbms_datapump.open(operation   => 'IMPORT',
                                        job_mode    => 'SCHEMA',
                                        remote_link => null,
                                        job_name    => p_job_name);
     -- 并行度设置, 如果数据量大, CPU多, 那么可以设置并行度大于1来快速导出
     -- dbms_datapump.set_parallel(handle=>v_job_handle,degree=>1);
    dbms_datapump.add_file(handle    => v_job_handle,
                            filename  => p_backupfile,
                            directory => p_backupdir,
                            filetype  => 1);

    dbms_datapump.add_file(handle    => v_job_handle,
                            filename  => p_logfile,
                            directory => p_logdir,
                            filetype  => dbms_datapump.KU$_FILE_TYPE_LOG_FILE);

    if v_from_user <> v_to_user then
        dbms_datapump.METADATA_REMAP(handle => v_job_handle,
                                  name => 'REMAP_SCHEMA'
                                  ,old_value => v_from_user
                                  ,value => v_to_user);
    end if;

    dbms_datapump.set_parameter(handle => v_job_handle
                                 ,name => 'TABLE_EXISTS_ACTION'
                                 ,value => 'REPLACE');

    if v_has_datapumpimp = 1 then
      dbms_datapump.metadata_filter(handle => v_job_handle,
                                      name => 'EXCLUDE_NAME_EXPR',
                                      value => '=(''DATAPUMPIMP'')',
                                      object_type => 'PROCEDURE');
    end if;

    dbms_datapump.start_job(v_job_handle);
    dbms_datapump.wait_for_job(handle =>v_job_handle,job_state=>v_job_state);
    dbms_datapump.detach(v_job_handle);
    exception
       when others then
         dbms_datapump.detach(v_job_handle);
         raise_application_error(-20011,'恢复出错，错误代码:'||to_char(sqlcode)||'错误原因:'||sqlerrm);
    end;

    /*授权*/
    if v_to_user <> v_app_user then
      begin
      for t in ( select a.OBJECT_NAME,a.OBJECT_TYPE
                 from user_objects a
                where a.OBJECT_TYPE in ('PROCEDURE','FUNCTION','PACKAGE','PACKAGE BODY','SEQUENCE','TABLE','VIEW')
                   )
      loop
        if t.object_type = 'TABLE' then
        begin
          dbms_output.put_line('grant select,insert,delete, update on ' || t.object_name || ' to ' || v_app_user);
          execute immediate 'grant select,insert,delete, update on ' || t.object_name || ' to ' || v_app_user ;
        exception
          when others then
            v_remove_Error := 1;
            dbms_output.put_line('grant table failed');
        end;
        end if;

        if t.object_type = 'VIEW' OR t.object_type = 'SEQUENCE' then
        begin
          dbms_output.put_line('grant select  on ' || t.object_name || ' to ' || v_app_user);
          execute immediate 'grant select  on ' || t.object_name || ' to ' || v_app_user ;
        exception
          when others then
            v_remove_Error := 1;
            dbms_output.put_line('grant SEQUENCE failed');
        end;
        end if;

        if t.object_type = 'PROCEDURE' or t.object_type = 'FUNCTION' or t.object_type = 'PACKAGE' or t.object_type = 'PACKAGE BODY' then
          begin
            dbms_output.put_line('grant execute on ' || t.object_name || ' to ' || v_app_user);
            execute immediate 'grant execute on ' || t.object_name || ' to ' || v_app_user;
          exception
          when others then
            v_remove_Error := 1;
            dbms_output.put_line('grant PROCEDURE FUNCTION PACKAGE PACKAGE BODY failed');
          end;
        end if;

      end loop;
      end;
    end if;
end;

/

