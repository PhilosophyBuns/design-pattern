create view VKJCLASSINTERFACE as
  select decode(nvl(c_expkjmerger,'1'), '3', c_gradecode, c_fundcode) c_fundcode, c_gradecode, '1' c_expkjmerger
  from TKJCLASSINTERFACE
union
select decode(nvl(c_expkjmerger,'1'), '2', c_gradecode, c_fundcode) c_fundcode, c_gradecode, '2' c_expkjmerger
  from TKJCLASSINTERFACE
union
select c_fundcode, c_fundcode, '1' c_expkjmerger
  from TKJCLASSINTERFACE
union
select c_fundcode, c_fundcode, '2' c_expkjmerger
  from TKJCLASSINTERFACE
/

