create function GetShortCycleHold(fundcode in varchar2,regDate in varchar2,oriSource in varchar2,cfmDate in varchar2)
return integer
as
  m_chDate varchar2(8);
  m_hold integer;
  m_calChDate varchar2(8);
  m_oriSource  char(1);
  vsetupdate   varchar2(8);
begin
  select to_char(d_setupdate, 'YYYYMMDD')
    into vsetupdate
    from tfundinfo a
   where a.c_fundcode = fundcode;

  if regDate > vsetupdate  then
    m_orisource := '1';
  else
    m_orisource := '0';
  end if;

  select GetShortCycleChDate(fundcode,regDate,cfmDate,'1') into m_chDate from dual;

  if m_orisource = '0' then
    if m_chDate = regDate then
      m_calChDate := m_chDate;
    else
      select getrealdays(fundcode,'***',m_chDate,1) into m_calChDate from dual;
    end if;
  else
    select getrealdays(fundcode,'***',m_chDate,1) into m_calChDate from dual;
  end if;

  select to_date(cfmDate,'yyyymmdd') - to_date(m_calChDate,'yyyymmdd') into m_hold from dual;
  return m_hold;
end;


/

