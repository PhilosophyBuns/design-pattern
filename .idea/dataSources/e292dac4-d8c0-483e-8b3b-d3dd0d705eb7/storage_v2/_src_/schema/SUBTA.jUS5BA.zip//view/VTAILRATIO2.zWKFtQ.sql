create view VTAILRATIO2 as
  select c_fundcode, c_agencyno, f_sharemin, f_sharemax, f_ratio,c_tailtype, c_updateflag, d_begindate,f_tailratio,
       last_value(d_enddate) over(partition by c_fundcode, c_agencyno, d_begindate, c_tailtype
          order by d_enddate rows between unbounded preceding and unbounded following) d_enddate
  from (select c_fundcode, c_agencyno, f_sharemin, f_sharemax, f_ratio,nvl(a.c_tailtype, '0') c_tailtype, c_updateflag, d_begindate,f_tailratio,
               nvl(lead(d_begindate) over(partition by c_fundcode, c_agencyno, nvl(a.c_tailtype, '0')
                  order by d_begindate, f_sharemin),
                  to_date('20991231', 'yyyymmdd')) d_enddate
          from ttailratio2 a)
/

