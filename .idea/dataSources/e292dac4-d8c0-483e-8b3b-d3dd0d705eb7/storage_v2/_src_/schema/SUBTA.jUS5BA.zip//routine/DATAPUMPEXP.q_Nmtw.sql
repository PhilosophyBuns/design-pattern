create PROCEDURE "DATAPUMPEXP"
(
  p_backupfile varchar2,
  p_logfile varchar2,
  p_backupdir varchar2,
  p_logdir varchar2,
  p_job_name     varchar2,
  iAllFlag  integer
)
is
  v_job_handle  pls_integer;
  v_job_state   varchar2(20);
  v_remove_Error integer;
begin

  begin
  utl_file.fremove(p_backupdir,p_backupfile);
  exception when others then
    v_remove_Error := 1;
  end;

  begin
  utl_file.fremove(p_logdir,p_logfile);
  exception when others then
    v_remove_Error := 1;
  end;

  begin
  v_job_handle := dbms_datapump.open(operation   => 'EXPORT',
                                     job_mode    => 'SCHEMA',
                                     remote_link => null,
                                     job_name    => p_job_name);

  -- 并行度设置, 如果数据量大, CPU多, 那么可以设置并行度大于1来快速导出
  -- dbms_datapump.set_parallel(handle=>v_job_handle,degree=>1);
  dbms_datapump.add_file(handle    => v_job_handle,
                            filename  => p_backupfile,
                            directory => p_backupdir,
                            filetype  => dbms_datapump.KU$_FILE_TYPE_DUMP_FILE);

  dbms_datapump.add_file(handle    => v_job_handle,
                            filename  => p_logfile,
                            directory => p_logdir,
                            filetype  => dbms_datapump.KU$_FILE_TYPE_LOG_FILE);
  if iAllFlag <> 1 then
    dbms_datapump.metadata_filter(handle => v_job_handle,
                                      name => 'EXCLUDE_NAME_EXPR',
                                      value => 'LIKE(''%_HIS%'')',
                                      object_type => 'TABLE');
  end if;


  dbms_datapump.start_job(v_job_handle);
  dbms_datapump.wait_for_job(handle =>v_job_handle,job_state=>v_job_state);
  exception
     when others then
       dbms_datapump.detach(v_job_handle);
       raise_application_error(-20010,'备份出错，错误代码:'||to_char(sqlcode)||'错误原因:'||sqlerrm);
  end;
  dbms_datapump.detach(v_job_handle);

end;

/

