create view VFUNDBENCHMARK as
  (
select c_fundcode,
       d_begindate,
       nvl(lead(d_begindate, 1) over(partition by c_fundcode order by d_begindate), to_date('20991231', 'yyyymmdd')) d_enddate,
       f_datumrate
  from tfundbenchmark)

/

