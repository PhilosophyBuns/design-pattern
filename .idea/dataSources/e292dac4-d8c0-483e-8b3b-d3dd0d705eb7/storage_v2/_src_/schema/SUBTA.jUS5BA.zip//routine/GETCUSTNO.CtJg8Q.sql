create function GetCustno(tacode in varchar2,fundacco in varchar2)
return varchar2
as
v_tacode varchar2(2);
v_custno varchar2(12);
v_fundacco varchar2(12);
begin
  v_tacode := tacode;
  v_fundacco := fundacco;
  if v_tacode in ('16','27','09') then
    v_custno := v_fundacco;
  else
    if v_tacode = '15' then
      v_custno := '00'||substr(v_fundacco,4,8)||substr(v_fundacco,3,1)||substr(v_fundacco,12,1);
    else
      v_custno := '000'||substr(v_fundacco,4,9);
    end if;
  end if;
  return v_custno;
end;


/

