create view VSERVICERATIO as
  select c_fundcode, c_agencyno, c_flag,
       f_sharemin, f_sharemax, f_ratio, d_begindate,
       last_value(d_enddate)over(partition by c_fundcode, c_agencyno, d_begindate
                                     order by d_enddate
                                      rows between unbounded preceding
                                               and unbounded following) d_enddate
  from (select c_fundcode, c_agencyno, c_flag,
               f_sharemin, f_sharemax, f_ratio, d_begindate,
               nvl(lead(d_begindate)over(partition by c_fundcode, c_agencyno
                                             order by d_begindate, f_sharemin),
               to_date('20991231', 'yyyymmdd')) d_enddate
          from tserviceratio)

/

