create function Genaccount(tacode in varchar2,custtype in varchar2,agencyno in varchar2,AccountSerial in integer,
                                      sysparam_fundacco3 in varchar2,sysparam_AccoCheckBitRule in varchar2)
return varchar2
as
  v_macno integer;
  v_accotmp varchar2(12);
  v_AccSerial integer;
  v_tacode varchar2(2);
  v_agencyno varchar2(3);
  v_custtype varchar2(1);
  v_fundacco3 varchar2(1);
  v_accoCheckBitRule varchar2(1);
begin
  v_tacode := tacode;
  v_agencyno := agencyno;
  v_custtype := custtype;
  v_accserial := mod(AccountSerial,100000000);
  v_fundacco3 := sysparam_fundacco3;
  v_accocheckbitrule := sysparam_accocheckbitrule;
  v_macno := 0;

  if v_custtype = '1' then
    v_accotmp := v_tacode||'1'||lpad(v_accserial,8,'0');
  else
    if v_fundacco3 = '0' then
      v_accotmp := v_tacode||'6'||lpad(v_accserial,8,'0');
    else
      v_accotmp := v_tacode||'0'||lpad(v_accserial,8,'0');
    end if;
  end if;
  if v_accoCheckBitRule = '1' then
    for i in 1..11
    loop
      v_macno := v_macno + (ascii(substr(v_accotmp,i,1))-ascii('0'))*i;
    end loop;
  else
    for i in 0..10
    loop
      v_macno := v_macno + (ascii(substr(v_accotmp,i,1))-ascii('0'));
    end loop;
  end if;
  v_accotmp := v_accotmp || to_char(mod(v_macno,10));
  return v_accotmp;
end;


/

