create function GetYEBacco(GTACode in varchar2, custtype in char, AccountSerial in integer, sysparam_fundacco3 in varchar2,
                                       AccoCheckBitRule in integer )
  return varchar2 as
  i          number(9);
  nAccSerail number(7);
  FundAcco   varchar2(12);
  accotmp    varchar2(12);
  v_fundacco3 varchar2(1);
  t          char(1);
  macno      integer;

begin
  i          := AccountSerial / 9999999;
  nAccSerail := mod(AccountSerial, 9999999);
  v_fundacco3 := sysparam_fundacco3;

  case
    when i = 0 then
      t := 'A';
    when i = 1 then
      t := 'B';
    when i = 2 then
      t := 'C';
    when i = 3 then
      t := 'D';
    when i = 4 then
      t := 'E';
    when i = 5 then
      t := 'F';
    when i = 6 then
      t := 'G';
    when i = 7 then
      t := 'H';
    when i = 8 then
      t := 'I';
    when i = 9 then
      t := 'J';
    when i = 10 then
      t := 'K';
    when i = 11 then
      t := 'L';
    when i = 12 then
      t := 'M';
    when i = 13 then
      t := 'N';
    when i = 14 then
      t := 'O';
    when i = 15 then
      t := 'P';
    when i = 16 then
      t := 'Q';
    when i = 17 then
      t := 'R';
    when i = 18 then
      t := 'S';
    when i = 19 then
      t := 'T';
    when i = 20 then
      t := 'U';
    when i = 21 then
      t := 'V';
    when i = 22 then
      t := 'W';
    when i = 23 then
      t := 'X';
    when i = 24 then
      t := 'Y';
    when i = 25 then
      t := 'Z';
  end case;

  if custtype = '1' then
    accotmp := lpad(GTACode, 2, 0) || '1' || t || lpad(nAccSerail, 7, 0);
  else
    if v_fundacco3 = '0' then
      accotmp := lpad(GTACode, 2, 0) || '6' || t || lpad(nAccSerail, 7, 0);
    else
      accotmp := lpad(GTACode, 2, 0) || '0' || t || lpad(nAccSerail, 7, 0);
    end if;
  end if;
  macno   := 0;
  if AccoCheckBitRule = 1 then
    for i in 1 .. 11 loop
      macno := macno + ascii(substr(accotmp, i, 1)) * i;
    end loop;
  else
    for i in 1 .. 11 loop
      macno := macno + ascii(substr(accotmp, i, 1));
    end loop;
  end if;
  FundAcco := lpad(accotmp, 11, '0') || mod(macno, 10);

  return FundAcco;
end;


/

