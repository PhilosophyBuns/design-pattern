create FUNCTION ADDMONTHS(d in DATE, m in INTEGER ) return date as
  m_datetmp date;
  m_strdatetmp char(8);
  m_strdate char(8);
  m_daytmp  integer;
  m_day  integer;
begin
  m_datetmp := add_months(d, m);
  m_strdate := to_char(d, 'yyyymmdd');
  m_strdatetmp := to_char(m_datetmp, 'yyyymmdd');
  m_daytmp := to_number(substr(m_strdatetmp, 7, 2));
  m_day := to_number(substr(m_strdate, 7, 2));
  if m_daytmp > m_day then
  begin
    m_datetmp := to_date(substr(m_strdatetmp, 1, 6)||to_char(m_day), 'yyyymmdd');
  end;
  end if;

  return m_datetmp;
end;

/

