create view VDEALFUND as
  select c_fundcode,nvl(l_dealtime,0) dealtime from tdealflag a
where exists (select 1 from tsysparameter b where b.c_item='DispartFundDeal' and b.c_value='1')
  and a.d_cdate=(select to_date(c_value,'yyyymmdd') from tsysparameter where c_item='SysDate')
union
select c_fundcode,0 dealtime from tfundinfo a
where not exists (select 1 from tsysparameter b where b.c_item='DispartFundDeal' and b.c_value='1')
/

