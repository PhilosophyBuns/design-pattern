create function sgsh_sms
(
  p_date in varchar2,
  p_fundlist in varchar2
)return varchar2
is
  cursor cur_rss
  (
    p_date in varchar2,
    p_fundlist in varchar2,
    p_businflag in varchar2
  )
  is
    select a.c_flag,
           a.c_fundcode,
           decode(a.c_fundcode,'580001','嘉禾',
                               '580002','双动力',
                               '580003','轮动',
                               '580005','策略',
                               '580006','新经济',
                               '580007','创业',
                               '580008','产业',
                               '582001','优信',
                               '582201','优信',
                               '582002','增利',
                               '582202','增利',
                               '583001','货币',
                               '583101','货币',
                               '585001','中证新兴',a.c_fundcode) c_fundname,
           a.c_businflag,
           bf.c_businname,
           a.c_agencyno,
           ai.c_agencyname,
           a.f_totalbalance
      from (
              select
                     decode(c_fundcode,'582201','582001','582202','582002','583101','583001',c_fundcode) c_fundcode,
                     decode(a.c_businflag,'13','03','16','02',a.c_businflag) c_businflag,
                     a.c_agencyno,
                     grouping(a.c_agencyno) c_flag,
                     sum(decode(a.c_businflag,'01',f_confirmbalance-nvl(f_totalfare, 0),
                                              '02',f_confirmbalance-nvl(f_totalfare, 0),
                                              f_confirmbalance+nvl(f_totalfare, 0))) f_totalbalance
                from tconfirm a
               where a.d_cdate = to_date(p_date, 'yyyymmdd')
                 and instr(p_businflag, a.c_businflag) > 0
                 and nvl(instr(p_fundlist, a.c_fundcode), 1) > 0
                 and a.c_status = '1'
               group by decode(c_fundcode,'582201','582001','582202','582002','583101','583001',c_fundcode),
                        decode(a.c_businflag,'13','03','16','02',a.c_businflag),
                        cube(a.c_agencyno)
           )a, tfundinfo fi, tagencyinfo ai, tbusinflag bf
     where a.c_fundcode = fi.c_fundcode
       and a.c_agencyno = ai.c_agencyno(+)
       and a.c_businflag = bf.c_businflag
       and (a.c_flag = '1' or f_totalbalance > 1000000)
     order by a.c_fundcode, a.c_businflag, a.c_flag desc, a.f_totalbalance desc;
  rss_info cur_rss%rowtype;

  cursor cur_rgsum
  (
    p_date in varchar2,
    p_fundcode in varchar2
  )
  is
    select a.c_flag,
           a.c_fundcode,
           decode(a.c_fundcode,'580001','嘉禾',
                               '580002','双动力',
                               '580003','轮动',
                               '580005','策略',
                               '580006','新经济',
                               '580007','创业',
                               '580008','产业',
                               '582001','优信',
                               '582201','优信',
                               '582002','增利',
                               '582202','增利',
                               '583001','货币',
                               '583101','货币',
                               '585001','中证新兴',a.c_fundcode) c_fundname,
           a.c_businflag,
           bf.c_businname,
           a.c_agencyno,
           ai.c_agencyname,
           a.f_totalbalance
      from (
              select decode(c_fundcode,'582201','582001','582202','582002','583101','583001',c_fundcode) c_fundcode,
                     decode(a.c_businflag,'13','03','16','02',a.c_businflag) c_businflag,
                     a.c_agencyno,
                     grouping(a.c_agencyno) c_flag,
                     sum(decode(a.c_businflag,'01',f_confirmbalance-nvl(f_totalfare, 0),f_confirmbalance+nvl(f_totalfare, 0))) f_totalbalance
                from tconfirm a
               where a.d_cdate <= to_date(p_date, 'yyyymmdd')
                 and a.c_businflag in ('01')
                 and a.c_fundcode = p_fundcode
                 and a.c_status = '1'
               group by decode(c_fundcode,'582201','582001','582202','582002','583101','583001',c_fundcode),
                        decode(a.c_businflag,'13','03','16','02',a.c_businflag),
                        cube(a.c_agencyno)
           )a, tfundinfo fi, tagencyinfo ai, tbusinflag bf
     where a.c_fundcode = fi.c_fundcode
       and a.c_agencyno = ai.c_agencyno(+)
       and a.c_businflag = bf.c_businflag
       and (a.c_flag = '1' or f_totalbalance > 1000000)
     order by a.c_fundcode, a.c_businflag, a.c_flag desc, a.f_totalbalance desc;
  rgsum_info cur_rgsum%rowtype;

  sDate varchar2(8);
  sReqDate varchar2(50);
  sFundcode varchar2(10);
  sFundlist varchar2(4000);
  ResData varchar2(4000);
  sumRG number(16,2) := 0;
  sumSG number(16,2) := 0;
  sumSH number(16,2) := 0;
  sTmpStr varchar2(100);
  iFundCount integer := 0;

  function GetBanlanceStr(f_balance in number)
    return varchar2
  is
    sTmpStr varchar2(100);
    iBillion integer := 100000000; --一亿，单位，常量
    iWan integer := 10000; --一万，单位，常量
    sTo_Char varchar2(50) := 'fm99999999999990.0';
  begin
    if f_balance>=iBillion then
      sTmpStr := to_char(trunc(f_balance/iBillion, 1), sTo_Char)||'亿';
    elsif f_balance>=iWan then
      sTmpStr := to_char(trunc(f_balance/iWan))||'万';
    else
      sTmpStr := trim(to_char(trunc(f_balance/iWan,1), '0.9'))||'万';
    end if;

    return sTmpStr;
  end;

begin
  sDate := trim(p_date);
  if sDate is null then
    select c_value into sDate from tsysparameter where c_item = 'SysDate';
  end if;

  select to_char(max(d_date),'fmdd')||'日' into sReqDate
    from topenday t
   where t.l_workflag = 1
     and t.d_date < to_date(sDate, 'yyyymmdd');

  --多基金以逗号分隔，为空则不限制
  sFundlist := trim(p_fundlist);

  /* 统计认购数据开始 */
  if cur_rss%isopen then
    close cur_rss;
  end if;
  open cur_rss(sDate, sFundlist, '01,');
  loop
    fetch cur_rss into rss_info;
    exit when cur_rss%notfound;

    if (sFundcode is null) or (sFundcode<>rss_info.c_fundcode) then
      if (sFundcode<>rss_info.c_fundcode) and (trim(ResData) is not null) then
        ResData := substr(ResData, 1, length(ResData)-1);
        ResData := ResData || '。';

        if cur_rgsum%isopen then
          close cur_rgsum;
        end if;
        open cur_rgsum(sDate, sFundcode);
        loop
          fetch cur_rgsum into rgsum_info;
          exit when cur_rgsum%notfound;

          sTmpStr := GetBanlanceStr(rgsum_info.f_totalbalance);

          if rgsum_info.c_flag = '1' then
            --销售商汇总
            ResData := ResData || '累计' || rgsum_info.c_businname || sTmpStr || ',';
          else
            ResData := ResData || rgsum_info.c_agencyname || sTmpStr || ',';
          end if;

        end loop;
        close cur_rgsum;
      end if;

      if trim(ResData) is not null then
        ResData := substr(ResData, 1, length(ResData)-1);
        ResData := ResData || ';';
      end if;
      ResData := ResData || rss_info.c_fundname;
      sFundcode := rss_info.c_fundcode;
    end if;

    sTmpStr := GetBanlanceStr(rss_info.f_totalbalance);
    if rss_info.c_flag = '1' then
      --销售商汇总
      ResData := ResData || rss_info.c_businname || sTmpStr || ',';

      if rss_info.c_businflag = '01' then
        sumRG := sumRG + rss_info.f_totalbalance; --认购总金额
      end if;
    else
      ResData := ResData || rss_info.c_agencyname || sTmpStr || ',';
    end if;

  end loop;
  close cur_rss;

  if (trim(sFundcode) is not null) and trim(ResData) is not null then
    ResData := substr(ResData, 1, length(ResData)-1);
    ResData := ResData || '。';

    if cur_rgsum%isopen then
      close cur_rgsum;
    end if;
    open cur_rgsum(sDate, sFundcode);
    loop
      fetch cur_rgsum into rgsum_info;
      exit when cur_rgsum%notfound;

      sTmpStr := GetBanlanceStr(rgsum_info.f_totalbalance);
      if rgsum_info.c_flag = '1' then
        --销售商汇总
        ResData := ResData || '累计' || rgsum_info.c_businname || sTmpStr || ',';
      else
        ResData := ResData || rgsum_info.c_agencyname || sTmpStr || ',';
      end if;

    end loop;
    close cur_rgsum;

    if trim(ResData) is not null then
      ResData := substr(ResData, 1, length(ResData)-1);
      ResData := ResData || '。';
    end if;
  end if;
  /* 统计认购数据结束 */

  /* 统计申购赎回数据开始 */
  sFundcode := null;
  if cur_rss%isopen then
    close cur_rss;
  end if;
  open cur_rss(sDate, sFundlist, '02,03,13,16,');
  loop
    fetch cur_rss into rss_info;
    exit when cur_rss%notfound;

    if (sFundcode is null) or (sFundcode<>rss_info.c_fundcode) then
      if (sFundcode<>rss_info.c_fundcode) and (trim(ResData) is not null) then
        ResData := substr(ResData, 1, length(ResData)-1);
        ResData := ResData || ';';
      end if;

      ResData := ResData || rss_info.c_fundname;
      iFundCount := iFundCount + 1;
      sFundcode := rss_info.c_fundcode;
    end if;

    sTmpStr := GetBanlanceStr(rss_info.f_totalbalance);
    if rss_info.c_flag = '1' then
      --销售商汇总
      ResData := ResData || rss_info.c_businname || sTmpStr || ',';

      if rss_info.c_businflag = '02' then
        sumSG := sumSG + rss_info.f_totalbalance; --申购总金额
      elsif rss_info.c_businflag = '03' then
        sumSH := sumSH + rss_info.f_totalbalance; --赎回总金额
      end if;
    else
      ResData := ResData || rss_info.c_agencyname || sTmpStr || ',';
    end if;

  end loop;
  close cur_rss;

  if trim(ResData) is not null then
    ResData := substr(ResData, 1, length(ResData)-1);
    ResData := sReqDate || ResData || '。';
  end if;

  if iFundCount>1 then
    --大于一只基金则汇总显示:当日旗下基金累计申购666万,累计赎回555万
    resdata := resdata||'当日旗下基金';

    sTmpStr := GetBanlanceStr(sumSG);
    resdata := resdata||'累计申购'||sTmpStr||',';

    sTmpStr := GetBanlanceStr(sumSH);
    resdata := resdata||'累计赎回'||sTmpStr || '。';
  end if;
  /* 统计申购赎回数据结束 */

  return ResData;
end;


/

