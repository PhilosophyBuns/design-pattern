create PROCEDURE pCreateView(sTable1 VARCHAR2,sTable2 VARCHAR2,sView VARCHAR2,nModified NUMBER)
AS
	sColName	VARCHAR2(31);
	sTmp		VARCHAR2(3072);
	nNext		NUMBER;
	sSql		VARCHAR2(7168);
	nCnt		NUMBER;
	nCreate		NUMBER;
	CURSOR CSR_VIEW IS
		SELECT CNAME FROM COL
		WHERE TNAME = sTable1
		ORDER BY COLNO
	;
BEGIN
	nCnt := 0;
	SELECT COUNT(*) INTO nCnt FROM OBJ WHERE OBJECT_TYPE = 'VIEW' AND OBJECT_NAME = sView;
	nCreate := 0;
	IF (nCnt = 1) AND (nModified = 1) THEN
		sSql := 'DROP VIEW ' || sView;
		EXECUTE IMMEDIATE sSql;
		nCreate := 1;
	ELSIF nCnt = 0 THEN
		nCreate := 1;
	END IF;
	IF nCreate = 1 THEN
    	OPEN CSR_VIEW;
    	sTmp := '';
    	nNext := 0;
    	LOOP
    		sColName := '';
    		FETCH CSR_VIEW INTO sColName;
    	EXIT WHEN CSR_VIEW%NOTFOUND;
    		IF nNext = 1 THEN
    			sTmp := sTmp || ',';
    		END IF;
    		sColName := TRIM(sColName);
    		sTmp := sTmp || sColName;
    		nNext := 1;
    	END LOOP;
    	CLOSE CSR_VIEW;
    	sSql := 'CREATE VIEW ' || sView || ' AS SELECT ' || sTmp || ' FROM ' ||sTable1 ||
    					 ' UNION all SELECT ' || sTmp || ' FROM ' || sTable2;
    	EXECUTE IMMEDIATE sSql;
    END IF;
END pCreateView;
/

