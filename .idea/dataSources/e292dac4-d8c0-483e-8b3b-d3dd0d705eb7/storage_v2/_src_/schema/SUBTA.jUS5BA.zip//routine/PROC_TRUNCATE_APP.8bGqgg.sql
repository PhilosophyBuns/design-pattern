create procedure proc_truncate_app(p_tablename varchar2)
as
begin
  execute immediate'truncate table '||p_tablename;
end;


/

