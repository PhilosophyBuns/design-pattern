create function GetFilterKJFundCodes
return varchar2
is
    aFundCodes varchar2(200);
begin
    aFundCodes := '519599;519598;940028;940038;519512;519513;519521;519522;519523';

    return aFundCodes;
end GetFilterKJFundCodes;


/

