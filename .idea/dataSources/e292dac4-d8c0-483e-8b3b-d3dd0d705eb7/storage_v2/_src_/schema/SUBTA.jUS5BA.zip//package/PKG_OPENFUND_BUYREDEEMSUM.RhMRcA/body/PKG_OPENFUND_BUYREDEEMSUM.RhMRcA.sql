create package body pkg_Openfund_BuyRedeemSum
is
  -- step 1 ----------------------------------------------------------------------------------------
  -- 创建自定义函数，分别用来获得销售商D_CDATE,基金+销售商D_CDATE、基金净值、销售商分类
  --------------------------------------------------------------------------------------------------
  function  func_agency_cdate(p_agency in varchar2) return varchar2 is
  begin
    return case when pkg_Openfund_BuyRedeemSum.v_hash_agency.exists(p_agency)
                     then pkg_Openfund_BuyRedeemSum.v_hash_agency(p_agency) else '00010101' end;
  end;

  function  func_fundagency_cdate(p_fundagency in varchar2) return date is
  begin
    return case when pkg_Openfund_BuyRedeemSum.v_hash_fundagency.exists(p_fundagency)
                     then pkg_Openfund_BuyRedeemSum.v_hash_fundagency(p_fundagency) else to_date('00010101','yyyymmdd') end;
  end;

  function  func_get_netvalue(p_fundcode in varchar2) return number is
  begin
    return case when pkg_Openfund_BuyRedeemSum.v_hash_netvalue.exists(p_fundcode)
                     then pkg_Openfund_BuyRedeemSum.v_hash_netvalue(p_fundcode) else 0 end;
  end;

  function  func_get_exchangerate(p_fundcode in varchar2) return number is
  begin
    return case when pkg_Openfund_BuyRedeemSum.v_hash_exchangerate.exists(p_fundcode)
                     then pkg_Openfund_BuyRedeemSum.v_hash_exchangerate(p_fundcode) else 1 end;
  end;

  FUNCTION  func_get_lastshares(p_fundcode IN VARCHAR2) RETURN NUMBER IS
  BEGIN
    RETURN CASE WHEN pkg_Openfund_BuyRedeemSum.v_hash_lastshares.exists(p_fundcode)
                     THEN pkg_Openfund_BuyRedeemSum.v_hash_lastshares(p_fundcode) ELSE 0 END;
  END;

  FUNCTION  func_get_lastasset(p_fundcode IN VARCHAR2) RETURN NUMBER IS
  BEGIN
    RETURN CASE WHEN pkg_Openfund_BuyRedeemSum.v_hash_lastasset.exists(p_fundcode)
                     THEN pkg_Openfund_BuyRedeemSum.v_hash_lastasset(p_fundcode) ELSE 0 END;
  END;

  FUNCTION  func_get_holddate(p_fundcode IN VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    RETURN CASE WHEN pkg_Openfund_BuyRedeemSum.v_hash_holddate.exists(p_fundcode)
                     THEN pkg_Openfund_BuyRedeemSum.v_hash_holddate(p_fundcode) ELSE '00010101' END;
  END;

  function  func_get_agencytype(p_agency in varchar2) return varchar2 is
  begin
    return case when pkg_Openfund_BuyRedeemSum.v_hash_agencytype.exists(p_agency)
                     then pkg_Openfund_BuyRedeemSum.v_hash_agencytype(p_agency) else '3' end;
  end;

  function  func_get_fundprop(p_fundcode in varchar2) return varchar2 is
  begin
    return case when pkg_Openfund_BuyRedeemSum.v_hash_fundprop.exists(p_fundcode)
                     then pkg_Openfund_BuyRedeemSum.v_hash_fundprop(p_fundcode) else '0' end;
  end;

  -- step 2 ----------------------------------------------------------------------------------------
  -- 统计账户数和份额、金额
  --------------------------------------------------------------------------------------------------
  procedure proc_summary(p_ddate in varchar2,p_fundcode in varchar2 default '',p_ifonlyopenfund in varchar2 default 'Y')
  is
    v_min_cdate_agency     varchar2(8)    := '00010101';
    v_max_cdate_agency     varchar2(8)    := '99991231';
    v_min_cdate_fundagency date           := to_date('00010101','yyyymmdd');
    v_max_cdate_fundagency date           := to_date('99991231','yyyymmdd');
    v_min_cdate_all        varchar2(8)    := '00010101';
    v_max_cdate_all        varchar2(8)    := '99991231';
    v_fundcode             varchar2(4000) := ltrim(rtrim(p_fundcode,', '),', ');
    v_ifhave_partition     pls_integer    := 1;
    v_TARole               char(1)        := 'A';
    v_TACode               char(2)        := 'XX';
    v_InterfaceMangerClass char(1)        := '0';
    v_InterFilterMangerType VARCHAR2(80)  := ';';
    v_ReportUnSendFundCode  VARCHAR2(80)  := ';';
  begin
    v_fundcode := case when v_fundcode is not null then ' and c_fundcode in ('''||replace(v_fundcode,',',''',''')||''')' else '' end;
    begin
      select TRIM(C_VALUE) into v_TARole
        from TSYSPARAMETER
       where C_ITEM = 'OrganRole'
         and c_class ='System';
    exception
      when no_data_found then
        v_TARole := 'A';
    end;
    begin
      select TRIM(C_VALUE) into v_TACode
        from TSYSPARAMETER
       where C_ITEM = 'TACode'
         and c_class ='System';
    exception
      when no_data_found then
        v_TACode := 'XX';
    end;
    begin
      select TRIM(C_VALUE) into v_InterfaceMangerClass
        from TSYSPARAMETER
       where C_ITEM = 'InterfaceMangerClass'
         and c_class ='System';
    exception
      when no_data_found then
        v_InterfaceMangerClass := '0';
    end;
    begin
      select NVL(TRIM(C_VALUE),';') into v_InterFilterMangerType
        from TSYSPARAMETER
       where C_ITEM = 'InterFilterMangerType'
         and c_class ='Interface';
    exception
      when no_data_found then
        v_InterFilterMangerType := ';';
    end;
    begin
      select NVL(TRIM(C_VALUE),';') into v_ReportUnSendFundCode
        from TSYSPARAMETER
       where C_ITEM = 'ReportUnSendFundCode'
         and c_class ='System';
    exception
      when no_data_found then
        v_ReportUnSendFundCode := ';';
    end;
    ------------------------------------------------------------------------------------------------
    -- 1. 删除临时表 tvalidacco,tsharecurrents_tmp_all
    ------------------------------------------------------------------------------------------------
    for t in (select 'truncate table '||table_name trun_tbl,'drop table '||table_name drop_tbl
              from   user_tables
              where  table_name in (upper('tvalidacco'),
                                    upper('tsharecurrents_tmp_all'))) loop
        execute immediate t.trun_tbl;
        execute immediate t.drop_tbl;
    end loop;

    ------------------------------------------------------------------------------------------------
    -- 2. 将所有 c_agencyno 以及对应的 d_cdate 存入哈希 v_hash_agency
    ------------------------------------------------------------------------------------------------
    for t in (select c_agencyno,cdate,min(cdate) over() min_cdate,max(cdate) over() max_cdate
              from   (select a.c_agencyno,getrealdays('******',a.c_agencyno,p_ddate,1) cdate from tagencyinfo a)) loop
        v_min_cdate_agency := t.min_cdate;
        v_max_cdate_agency := t.max_cdate;
        pkg_Openfund_BuyRedeemSum.v_hash_agency(t.c_agencyno) := t.cdate;
    end loop;

    ------------------------------------------------------------------------------------------------
    -- 3. 生成临时表 tvalidacco
    ------------------------------------------------------------------------------------------------
    execute immediate '
    create table tvalidacco
    (
      c_fundacco,
      c_custtype,
      constraint  pk_tvalidacco primary key(c_fundacco,c_custtype)
    ) organization index compress 1 nologging
    as
    select /*+ ordered use_merge(a,b) */
           a.c_fundacco,nvl(b.c_custtype,decode(substr(a.c_fundacco,3,1),''1'',''1'',''2'',''1'',''3'',''1'',''4'',''1'',''5'',''1'',''9'',''1'',''0'')) c_custtype
    from   taccoinfo a,tcustomerinfo b
    where  a.c_custno     = b.c_custno
    and    a.c_agencyno  in (select c.c_agencyno from tagencyinfo c)
    and    a.d_opendate  <= '||case when v_min_cdate_agency=v_max_cdate_agency
                                         then 'to_date('''||v_min_cdate_agency||''',''yyyymmdd'')'
                                         else 'to_date(pkg_Openfund_BuyRedeemSum.func_agency_cdate(a.c_agencyno),''yyyymmdd'')' end||'
    minus
    (
    select /*+ all_rows */
           d.c_fundacco,nvl(d.c_custtype,decode(substr(d.c_fundacco,3,1),''1'',''1'',''2'',''1'',''3'',''1'',''4'',''1'',''5'',''1'',''9'',''1'',''0'')) c_custtype
    from   taccorequest d
    where  d.c_businflag  = ''82''
    and    d.c_status     = ''1''
    and    d.c_agencyno  in (select c.c_agencyno from tagencyinfo c)
    and    d.d_cdate     <= '||case when v_min_cdate_agency=v_max_cdate_agency
                                         then 'to_date('''||v_min_cdate_agency||''',''yyyymmdd'')'
                                         else 'to_date(pkg_Openfund_BuyRedeemSum.func_agency_cdate(d.c_agencyno),''yyyymmdd'')' end||'
    union  all
    select /*+ all_rows */
           e.c_fundacco,nvl(e.c_custtype,decode(substr(e.c_fundacco,3,1),''1'',''1'',''2'',''1'',''3'',''1'',''4'',''1'',''5'',''1'',''9'',''1'',''0'')) c_custtype
    from   taccorequest_his e
    where  e.c_businflag  = ''82''
    and    e.c_status     = ''1''
    and    e.c_agencyno  in (select c.c_agencyno from tagencyinfo c)
    and    e.d_cdate     <= '||case when v_min_cdate_agency=v_max_cdate_agency
                                         then 'to_date('''||v_min_cdate_agency||''',''yyyymmdd''))'
                                         else 'to_date(pkg_Openfund_BuyRedeemSum.func_agency_cdate(e.c_agencyno),''yyyymmdd''))' end;

    ------------------------------------------------------------------------------------------------
    -- 4. 将所有 c_fundcode||c_agencyno 以及对应的 d_cdate 存入哈希 v_hash_fundagency
    ------------------------------------------------------------------------------------------------
    for t in (select c_fundagency,cdate,min(cdate) over() min_cdate,max(cdate) over() max_cdate
              from   (select b.c_fundcode||a.c_agencyno c_fundagency,
                             getrealdays(b.c_fundcode,a.c_agencyno,p_ddate,nvl(b.l_tnconfirm,1)) cdate
                      from   tagencyinfo a,tfundinfo b)) loop
        v_min_cdate_fundagency := to_date(t.min_cdate,'yyyymmdd');
        v_max_cdate_fundagency := to_date(t.max_cdate,'yyyymmdd');
        pkg_Openfund_BuyRedeemSum.v_hash_fundagency(t.c_fundagency) := to_date(t.cdate,'yyyymmdd');
    end loop;

    ------------------------------------------------------------------------------------------------
    -- 5. 将基金净值存入哈希 v_hash_netvalue,v_hash_lastshares,v_hash_lastasset,v_hash_holddate,v_hash_exchangerate
    ------------------------------------------------------------------------------------------------
    for v in (select tfd.c_fundcode,
                     nvl(tfd.f_netvalue,0) f_netvalue,
                     NVL(tfd.f_lastshares,0) f_lastshares,
                     NVL(tfd.f_lastasset,0) f_lastasset,
                     getrealdays(tfd.c_fundcode,'***',to_char(tfd.d_cdate,'yyyymmdd'),-1) d_holddate,
                     decode(tfi.c_moneytype,'840',nvl(tcr.f_exchangerate,100)/100,1) f_exchangerate
               from  tfundday tfd,tfundinfo tfi,tchangerate tcr,
                     (select c_fundcode,max(d_cdate) d_cdate
                      from   tfundday
                      where  d_date <= to_date(p_ddate,'yyyymmdd')
                      group  by c_fundcode) tfdt
               where tfd.d_cdate    = tfdt.d_cdate
                 and tfd.c_fundcode = tfdt.c_fundcode
                 and tfd.c_fundcode = tfi.c_fundcode
                 and tfd.d_date     = tcr.d_cdate(+)) loop
        pkg_Openfund_BuyRedeemSum.v_hash_netvalue(v.c_fundcode) := v.f_netvalue;
        pkg_Openfund_BuyRedeemSum.v_hash_lastshares(v.c_fundcode) := v.f_lastshares;
        pkg_Openfund_BuyRedeemSum.v_hash_lastasset(v.c_fundcode) := v.f_lastasset;
        pkg_Openfund_BuyRedeemSum.v_hash_holddate(v.c_fundcode) := v.d_holddate;
        pkg_Openfund_BuyRedeemSum.v_hash_exchangerate(v.c_fundcode) := v.f_exchangerate;
    end loop;

    ------------------------------------------------------------------------------------------------
    -- 6. 将销售商分类存入哈希 v_hash_agencytype
    --  9直销 1银行 2券商 4证券投资咨询公司 5专业销售机构
    ------------------------------------------------------------------------------------------------
    for a in (select c_agencyno,
                     case when c_agencyno='121' then '4'
                          else
                          case when c_agencytype='0' then '9'
                               else case substrb(c_agencyno,1,1)
                                    when '0' then '1'
                                    when '3' then '5'
                                    when '6' then '2'
                                    when '7' then '2'
                                  else '3' end end end c_agencytype
              from   tagencyinfo) loop
        pkg_Openfund_BuyRedeemSum.v_hash_agencytype(a.c_agencyno) := a.c_agencytype;
    end loop;

    ------------------------------------------------------------------------------------------------
    -- 7. 将基金类型存入哈希 v_hash_fundprop
    ------------------------------------------------------------------------------------------------
    for cur in (select c_fundcode,decode(c_fundcode,'762001','9','020029','4','020030','4', c_property) c_property
                  from (select fi.c_fundcode,decode(nvl(fi.c_outproperty,'*'),'*',decode(nvl(fi.c_shortcyclefinance, '0'),
                                                    '1',nvl(t.c_outproperty, fi.c_property),
                                                    decode(fi.c_property, '8', fi.C_RAISETYPE, fi.c_property)),fi.c_outproperty) c_property
                          from tfundinfo fi, tshortcyclefinance t
                         where fi.c_fundcode = t.c_fundcode(+)) ) loop
        pkg_Openfund_BuyRedeemSum.v_hash_fundprop(cur.c_fundcode) := cur.c_property;
    end loop;


    ------------------------------------------------------------------------------------------------
    -- 8. 生成临时表 tsharecurrents_tmp_all
    --   2011-04-14 新增字段：
    -- 个人持有股票型基金份额（份）(grgpfe)  个人持有混合型基金份额（份）(grhhfe)  个人持有债券型型基金份额（份）(grzqfe)
    -- 个人持有货币市场基金份额（份）(grhbfe)  个人持有QDII基金份额（份）(grqdfe)
    -- 机构持有股票型基金份额（份）(jggpfe)  机构持有混合型基金份额（份）(jghhfe)  机构持有债券型型基金份额（份）(jgzqfe)
    -- 机构持有货币市场基金份额（份）(jghbfe)  机构持有QDII基金份额（份）(jgqdfe)
    -- 个人持有股票型基金（元）(grgpje)  个人持有混合型基金净值（元）(grhhje)  个人持有债券型型基金净值（元）(grzqje)
    -- 个人持有货币市场基金净值（元）(grhbje)  个人持有QDII基金净值（元）(grqdje)
    -- 机构持有股票型基金净值（元）(jggpje)  机构持有混合型基金净值（元）(jghhje)  机构持有债券型型基金净值（元）(jgzqje)
    -- 机构持有货币市场基金净值（元）(jghbje)  机构持有QDII基金净值（元）(jgqdje)
    ------------------------------------------------------------------------------------------------
    v_min_cdate_all := least(v_min_cdate_agency,to_char(v_min_cdate_fundagency,'yyyymmdd'));
    v_max_cdate_all := greatest(v_max_cdate_agency,to_char(v_max_cdate_fundagency,'yyyymmdd'));
    select count(*) into v_ifhave_partition
    from   v$option
    where  upper(parameter) = upper('Partitioning')
    and    upper(value)     = upper('TRUE');

    if v_TARole = 'A' THEN
    begin
      if v_TACode = '16' THEN
        execute immediate '
        create table tsharecurrents_tmp_all
        (
          c_fundacco       not null,
          c_fundcode       not null,
          c_agencyno       not null,
          c_custtype       not null,
          c_agencytype     not null,
          d_cdate          not null,
          d_sharevaliddate not null,
          f_realshares     not null,
          f_gprealshares   not null,
          f_hhrealshares   not null,
          f_zqrealshares   not null,
          f_hbrealshares   not null,
          f_qdrealshares   not null,
          f_realsum        not null,
          f_gprealsum      not null,
          f_hhrealsum      not null,
          f_zqrealsum      not null,
          f_hbrealsum      not null,
          f_qdrealsum      not null
        ) nologging '||case when v_ifhave_partition=1 then '
        partition by list(f_realshares)
        (
          partition p_equal_to_zero    values(0)        nologging,
          partition p_larger_than_zero values(default)  nologging
        )' else null end||'
        as
        select /*+ full(a) */
               a.c_fundacco,a.c_fundcode,a.c_agencyno,nvl(a.c_custtype,decode(substr(a.c_fundacco,3,1),''1'',''1'',''2'',''1'',''3'',''1'',''4'',''1'',''5'',''1'',''9'',''1'',''0'')) c_custtype,
               cast(pkg_Openfund_BuyRedeemSum.func_get_agencytype(a.c_agencyno) as varchar2(1)) c_agencytype,
               trunc(a.d_cdate) d_cdate,trunc(a.d_sharevaliddate) d_sharevaliddate,
               nvl(a.f_lastshares,0) f_realshares,
               nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''0'',1,''5'',1,0) f_gprealshares ,
               nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''0'',0,''2'',0,''3'',0,''4'',0,''5'',0,''6'',0,1) f_hhrealshares ,
               nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''3'',1,''4'',1,0) f_zqrealshares ,
               nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''2'',1,0) f_hbrealshares ,
               nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''6'',1,0) f_qdrealshares ,
               nvl(a.f_lastshares,0)/pkg_Openfund_BuyRedeemSum.func_get_lastshares(a.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_lastasset(a.c_fundcode) f_realsum,
               nvl(a.f_lastshares,0)/pkg_Openfund_BuyRedeemSum.func_get_lastshares(a.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_lastasset(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''0'',1,''5'',1,0) f_gprealsum ,
               nvl(a.f_lastshares,0)/pkg_Openfund_BuyRedeemSum.func_get_lastshares(a.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_lastasset(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''0'',0,''2'',0,''3'',0,''4'',0,''5'',0,''6'',0,1) f_hhrealsum ,
               nvl(a.f_lastshares,0)/pkg_Openfund_BuyRedeemSum.func_get_lastshares(a.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_lastasset(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''3'',1,''4'',1,0) f_zqrealsum ,
               nvl(a.f_lastshares,0)/pkg_Openfund_BuyRedeemSum.func_get_lastshares(a.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_lastasset(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''2'',1,0) f_hbrealsum ,
               nvl(a.f_lastshares,0)/pkg_Openfund_BuyRedeemSum.func_get_lastshares(a.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_lastasset(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''6'',1,0) f_qdrealsum
        from   tsharecurrents_his a
        where  a.d_cdate          <= to_date(pkg_Openfund_BuyRedeemSum.func_get_holddate(a.c_fundcode),''yyyymmdd'')
        and    a.d_sharevaliddate  > to_date(pkg_Openfund_BuyRedeemSum.func_get_holddate(a.c_fundcode),''yyyymmdd'')
        and    a.c_fundcode       in (select x.c_fundcode from tfundinfo x where 1=1 '||
                                      case when v_fundcode is not null then v_fundcode else '' end||
                                      case when upper(p_ifonlyopenfund)='Y' then ' and x.c_property!=''8''' else null end||')
        union  all
        select /*+ full(b) */
               b.c_fundacco,b.c_fundcode,b.c_agencyno,nvl(b.c_custtype,decode(substr(b.c_fundacco,3,1),''1'',''1'',''2'',''1'',''3'',''1'',''4'',''1'',''5'',''1'',''9'',''1'',''0'')) c_custtype,
               cast(pkg_Openfund_BuyRedeemSum.func_get_agencytype(b.c_agencyno) as varchar2(1)) c_agencytype,
               trunc(b.d_cdate) d_cdate,trunc(b.d_sharevaliddate) d_sharevaliddate,
               nvl(b.f_lastshares,0) f_realshares,
               nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''0'',1,''5'',1,0 ) f_gprealshares ,
               nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''0'',0,''2'',0,''3'',0,''4'',0,''5'',0,''6'',0,1 ) f_hhrealshares ,
               nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''3'',1,''4'',1,0 ) f_zqrealshares ,
               nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''2'',1,0) f_hbrealshares ,
               nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''6'',1,0) f_qdrealshares ,
               nvl(b.f_lastshares,0)/pkg_Openfund_BuyRedeemSum.func_get_lastshares(b.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_lastasset(b.c_fundcode) f_realsum,
               nvl(b.f_lastshares,0)/pkg_Openfund_BuyRedeemSum.func_get_lastshares(b.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_lastasset(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''0'',1,''5'',1,0) f_gprealsum ,
               nvl(b.f_lastshares,0)/pkg_Openfund_BuyRedeemSum.func_get_lastshares(b.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_lastasset(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''0'',0,''2'',0,''3'',0,''4'',0,''5'',0,''6'',0,1) f_hhrealsum ,
               nvl(b.f_lastshares,0)/pkg_Openfund_BuyRedeemSum.func_get_lastshares(b.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_lastasset(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''3'',1,''4'',1,0) f_zqrealsum ,
               nvl(b.f_lastshares,0)/pkg_Openfund_BuyRedeemSum.func_get_lastshares(b.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_lastasset(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''2'',1,0) f_hbrealsum ,
               nvl(b.f_lastshares,0)/pkg_Openfund_BuyRedeemSum.func_get_lastshares(b.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_lastasset(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''6'',1,0) f_qdrealsum
        from   tsharecurrents b
        where  b.d_cdate          <= to_date(pkg_Openfund_BuyRedeemSum.func_get_holddate(b.c_fundcode),''yyyymmdd'')
        and    b.d_sharevaliddate  > to_date(pkg_Openfund_BuyRedeemSum.func_get_holddate(b.c_fundcode),''yyyymmdd'')
        and    b.c_fundcode       in (select x.c_fundcode from tfundinfo x where 1=1 '||
                                      case when v_fundcode is not null then v_fundcode else null end||
                                      case when upper(p_ifonlyopenfund)='Y' then ' and x.c_property!=''8''' else null end||')';
      else
        execute immediate '
        create table tsharecurrents_tmp_all
        (
          c_fundacco       not null,
          c_fundcode       not null,
          c_agencyno       not null,
          c_custtype       not null,
          c_agencytype     not null,
          d_cdate          not null,
          d_sharevaliddate not null,
          f_realshares     not null,
          f_gprealshares   not null,
          f_hhrealshares   not null,
          f_zqrealshares   not null,
          f_hbrealshares   not null,
          f_qdrealshares   not null,
          f_realsum        not null,
          f_gprealsum      not null,
          f_hhrealsum      not null,
          f_zqrealsum      not null,
          f_hbrealsum      not null,
          f_qdrealsum      not null
        ) nologging '||case when v_ifhave_partition=1 then '
        partition by list(f_realshares)
        (
          partition p_equal_to_zero    values(0)        nologging,
          partition p_larger_than_zero values(default)  nologging
        )' else null end||'
        as
        select /*+ full(a) */
               a.c_fundacco,a.c_fundcode,a.c_agencyno,nvl(a.c_custtype,decode(substr(a.c_fundacco,3,1),''1'',''1'',''2'',''1'',''3'',''1'',''4'',''1'',''5'',''1'',''9'',''1'',''0'')) c_custtype,
               cast(pkg_Openfund_BuyRedeemSum.func_get_agencytype(a.c_agencyno) as varchar2(1)) c_agencytype,
               trunc(a.d_cdate) d_cdate,trunc(a.d_sharevaliddate) d_sharevaliddate,
               nvl(a.f_lastshares,0) f_realshares,
               nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''0'',1,''5'',1,0) f_gprealshares ,
               nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''0'',0,''2'',0,''3'',0,''4'',0,''5'',0,''6'',0,1) f_hhrealshares ,
               nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''3'',1,''4'',1,0) f_zqrealshares ,
               nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''2'',1,0) f_hbrealshares ,
               nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''6'',1,0) f_qdrealshares ,
               nvl(a.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(a.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_exchangerate(a.c_fundcode) f_realsum,
               nvl(a.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(a.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_exchangerate(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''0'',1,''5'',1,0) f_gprealsum ,
               nvl(a.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(a.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_exchangerate(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''0'',0,''2'',0,''3'',0,''4'',0,''5'',0,''6'',0,1) f_hhrealsum ,
               nvl(a.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(a.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_exchangerate(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''3'',1,''4'',1,0) f_zqrealsum ,
               nvl(a.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(a.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_exchangerate(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''2'',1,0) f_hbrealsum ,
               nvl(a.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(a.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_exchangerate(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''6'',1,0) f_qdrealsum
        from   tsharecurrents_his a
        where  a.d_cdate          <= to_date('''||v_max_cdate_all||''',''yyyymmdd'')
        and    a.d_sharevaliddate  > to_date('''||v_min_cdate_all||''',''yyyymmdd'')
        and    a.c_fundcode       in (select x.c_fundcode from tfundinfo x where 1=1 '||
                                      case when v_fundcode is not null then v_fundcode else '' end||
                                      case when upper(p_ifonlyopenfund)='Y' then ' and x.c_property!=''8''' else null end||')
        union  all
        select /*+ full(b) */
               b.c_fundacco,b.c_fundcode,b.c_agencyno,nvl(b.c_custtype,decode(substr(b.c_fundacco,3,1),''1'',''1'',''2'',''1'',''3'',''1'',''4'',''1'',''5'',''1'',''9'',''1'',''0'')) c_custtype,
               cast(pkg_Openfund_BuyRedeemSum.func_get_agencytype(b.c_agencyno) as varchar2(1)) c_agencytype,
               trunc(b.d_cdate) d_cdate,trunc(b.d_sharevaliddate) d_sharevaliddate,
               nvl(b.f_lastshares,0) f_realshares,
               nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''0'',1,''5'',1,0 ) f_gprealshares ,
               nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''0'',0,''2'',0,''3'',0,''4'',0,''5'',0,''6'',0,1 ) f_hhrealshares ,
               nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''3'',1,''4'',1,0 ) f_zqrealshares ,
               nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''2'',1,0) f_hbrealshares ,
               nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''6'',1,0) f_qdrealshares ,
               nvl(b.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(b.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_exchangerate(b.c_fundcode) f_realsum,
               nvl(b.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(b.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_exchangerate(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''0'',1,''5'',1,0) f_gprealsum ,
               nvl(b.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(b.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_exchangerate(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''0'',0,''2'',0,''3'',0,''4'',0,''5'',0,''6'',0,1) f_hhrealsum ,
               nvl(b.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(b.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_exchangerate(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''3'',1,''4'',1,0) f_zqrealsum ,
               nvl(b.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(b.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_exchangerate(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''2'',1,0) f_hbrealsum ,
               nvl(b.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(b.c_fundcode)*pkg_Openfund_BuyRedeemSum.func_get_exchangerate(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''6'',1,0) f_qdrealsum
        from   tsharecurrents b
        where  b.d_cdate          <= to_date('''||v_max_cdate_all||''',''yyyymmdd'')
        and    b.d_sharevaliddate  > to_date('''||v_min_cdate_all||''',''yyyymmdd'')
        and    b.c_fundcode       in (select x.c_fundcode from tfundinfo x where 1=1 '||
                                      case when v_fundcode is not null then v_fundcode else null end||
                                      case when upper(p_ifonlyopenfund)='Y' then ' and x.c_property!=''8''' else null end||')';
      end if;
    end;
    else
      execute immediate '
      create table tsharecurrents_tmp_all
      (
        c_fundacco       not null,
        c_fundcode       not null,
        c_agencyno       not null,
        c_custtype       not null,
        c_agencytype     not null,
        d_cdate          not null,
        d_sharevaliddate not null,
        f_realshares     not null,
        f_gprealshares   not null,
        f_hhrealshares   not null,
        f_zqrealshares   not null,
        f_hbrealshares   not null,
        f_qdrealshares   not null,
        f_realsum        not null,
        f_gprealsum      not null,
        f_hhrealsum      not null,
        f_zqrealsum      not null,
        f_hbrealsum      not null,
        f_qdrealsum      not null
      ) nologging '||case when v_ifhave_partition=1 then '
      partition by list(f_realshares)
      (
        partition p_equal_to_zero    values(0)        nologging,
        partition p_larger_than_zero values(default)  nologging
      )' else null end||'
      as
      select /*+ full(a) */
             a.c_fundacco,a.c_fundcode,a.c_agencyno,nvl(t.c_custtype,decode(substr(a.c_fundacco,3,1),''1'',''1'',''2'',''1'',''3'',''1'',''4'',''1'',''5'',''1'',''9'',''1'',''0'')) c_custtype,
             cast(pkg_Openfund_BuyRedeemSum.func_get_agencytype(a.c_agencyno) as varchar2(1)) c_agencytype,
             trunc(a.d_cdate) d_cdate,trunc(a.d_sharevaliddate) d_sharevaliddate,
             nvl(a.f_lastshares,0) f_realshares,
             nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''0'',1,''5'',1,0) f_gprealshares ,
             nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''0'',0,''2'',0,''3'',0,''4'',0,''5'',0,''6'',0,1) f_hhrealshares ,
             nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''3'',1,''4'',1,0) f_zqrealshares ,
             nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''2'',1,0) f_hbrealshares ,
             nvl(a.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''6'',1,0) f_qdrealshares ,
             nvl(a.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(a.c_fundcode) f_realsum,
             nvl(a.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''0'',1,''5'',1,0) f_gprealsum ,
             nvl(a.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''0'',0,''2'',0,''3'',0,''4'',0,''5'',0,''6'',0,1) f_hhrealsum ,
             nvl(a.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''3'',1,''4'',1,0) f_zqrealsum ,
             nvl(a.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''2'',1,0) f_hbrealsum ,
             nvl(a.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(a.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(a.c_fundcode),''6'',1,0) f_qdrealsum
      from   tsharecurrents_his a,tvalidacco t
      where  a.c_fundacco       = t.c_fundacco(+)
      and    a.d_cdate          <= to_date('''||v_max_cdate_all||''',''yyyymmdd'')
      and    a.d_sharevaliddate  > to_date('''||v_min_cdate_all||''',''yyyymmdd'')
      and    a.c_fundcode       in (select x.c_fundcode from tfundinfo x where 1=1 '||
                                    case when v_fundcode is not null then v_fundcode else '' end||
                                    case when upper(p_ifonlyopenfund)='Y' then ' and x.c_property!=''8''' else null end||')
      union  all
      select /*+ full(b) */
             b.c_fundacco,b.c_fundcode,b.c_agencyno,nvl(t.c_custtype,decode(substr(b.c_fundacco,3,1),''1'',''1'',''2'',''1'',''3'',''1'',''4'',''1'',''5'',''1'',''9'',''1'',''0'')) c_custtype,
             cast(pkg_Openfund_BuyRedeemSum.func_get_agencytype(b.c_agencyno) as varchar2(1)) c_agencytype,
             trunc(b.d_cdate) d_cdate,trunc(b.d_sharevaliddate) d_sharevaliddate,
             nvl(b.f_lastshares,0) f_realshares,
             nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''0'',1,''5'',1,0 ) f_gprealshares ,
             nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''0'',0,''2'',0,''3'',0,''4'',0,''5'',0,''6'',0,1 ) f_hhrealshares ,
             nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''3'',1,''4'',1,0 ) f_zqrealshares ,
             nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''2'',1,0) f_hbrealshares ,
             nvl(b.f_lastshares,0)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''6'',1,0) f_qdrealshares ,
             nvl(b.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(b.c_fundcode) f_realsum,
             nvl(b.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''0'',1,''5'',1,0) f_gprealsum ,
             nvl(b.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''0'',0,''2'',0,''3'',0,''4'',0,''5'',0,''6'',0,1) f_hhrealsum ,
             nvl(b.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''3'',1,''4'',1,0) f_zqrealsum ,
             nvl(b.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''2'',1,0) f_hbrealsum ,
             nvl(b.f_lastshares,0)*pkg_Openfund_BuyRedeemSum.func_get_netvalue(b.c_fundcode)*decode(pkg_Openfund_BuyRedeemSum.func_get_fundprop(b.c_fundcode),''6'',1,0) f_qdrealsum
      from   tsharecurrents b,tvalidacco t
      where  b.c_fundacco       = t.c_fundacco(+)
      and    b.d_cdate          <= to_date('''||v_max_cdate_all||''',''yyyymmdd'')
      and    b.d_sharevaliddate  > to_date('''||v_min_cdate_all||''',''yyyymmdd'')
      and    b.c_fundcode       in (select x.c_fundcode from tfundinfo x where 1=1 '||
                                    case when v_fundcode is not null then v_fundcode else null end||
                                    case when upper(p_ifonlyopenfund)='Y' then ' and x.c_property!=''8''' else null end||')';
    end if;
    ------------------------------------------------------------------------------------------------
    -- 9. 从tsharecurrents_tmp_all生成份额、金额统计数据
    ------------------------------------------------------------------------------------------------
    delete from topenfund_statistics where d_date=p_ddate;

    if (v_TARole = 'A') and (v_TACode = '16') then
    execute immediate '
       insert into topenfund_statistics(d_date,zfe,gefe,grgpfe,grhhfe,grzqfe, grhbfe,grqdfe,
                                        jgfe,jggpfe,jghhfe,jgzqfe, jghbfe,jgqdfe,
                                        zxfe,yhfe,qszfe,zqzxjgfe,zyxsjgfe,zje,
                                        gezje,grgpje, grhhje,grzqje, grhbje,grqdje,
                                        jgzje,jggpje,jghhje,jgzqje,jghbje,jgqdje,
                                        zxzje,yhzje,qszje,zqzxjgje,zyxsjgje)
       select :1,
              nvl(sum(b.f_realshares),0) zfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_realshares,0)),0) gefe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_gprealshares,0)),0) grgpfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_hhrealshares,0)),0) grhhfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_zqrealshares,0)),0) grzqfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_hbrealshares,0)),0) grhbfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_qdrealshares,0)),0) grqdfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_realshares)),0) jgfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_gprealshares)),0) jggpfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_hhrealshares)),0) jghhfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_zqrealshares)),0) jgzqfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_hbrealshares)),0) jghbfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_qdrealshares)),0) jgqdfe,

              nvl(sum(decode(b.c_agencytype,''1'',0,''2'',0,''4'',0,''5'',0,b.f_realshares)),0) zxfe,
              nvl(sum(decode(b.c_agencytype,''1'',b.f_realshares,0)),0) yhfe,
              nvl(sum(decode(b.c_agencytype,''2'',b.f_realshares,0)),0) qszfe,
              nvl(sum(decode(b.c_agencytype,''4'',b.f_realshares,0)),0) zqzxjgfe,
              nvl(sum(decode(b.c_agencytype,''5'',b.f_realshares,0)),0) zyxsjgfe,
              nvl(round(sum(b.f_realsum),2),0) zje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_realsum,0)),2),0) gezje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_gprealsum,0)),2),0) grgpje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_hhrealsum,0)),2),0) grhhje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_zqrealsum,0)),2),0) grzqje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_hbrealsum,0)),2),0) grhbje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_qdrealsum,0)),2),0) grqdje,
              nvl(round(sum(b.f_realsum),2),0)-nvl(round(sum(decode(b.c_custtype,''1'',b.f_realsum,0)),2),0) jgzje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_gprealsum)),2),0) jggpje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_hhrealsum)),2),0) jghhje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_zqrealsum)),2),0) jgzqje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_hbrealsum)),2),0) jghbje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_qdrealsum)),2),0) jgqdje,
              nvl(round(sum(decode(b.c_agencytype,''1'',0,''2'',0,''4'',0,''5'',0,b.f_realsum)),2),0) zxzje,
              nvl(round(sum(decode(b.c_agencytype,''1'',b.f_realsum,0)),2),0) yhzje,
              nvl(round(sum(decode(b.c_agencytype,''2'',b.f_realsum,0)),2),0) qszje,
              nvl(round(sum(decode(b.c_agencytype,''4'',b.f_realsum,0)),2),0) zqzxjgje,
              nvl(round(sum(decode(b.c_agencytype,''5'',b.f_realsum,0)),2),0) zyxsjgje
       from   tsharecurrents_tmp_all b,tfundinfo tfi
       where  b.f_realshares      > 0
       and    b.d_cdate          <= pkg_Openfund_BuyRedeemSum.func_get_holddate(b.c_fundcode)
       and    b.d_sharevaliddate  > pkg_Openfund_BuyRedeemSum.func_get_holddate(b.c_fundcode)
       and    b.c_fundacco       != ''996000000000''
       and    b.c_fundcode   not in (''206101'',''206102'',''489057'',''489058'')
       and    b.c_fundcode=tfi.c_fundcode
       and    tfi.c_RptIsSend=''1''
       and    instr('''|| v_ReportUnSendFundCode ||''', b.c_fundcode)=0 ' ||
       case when v_InterfaceMangerClass ='1' then
                 ' and not exists(select 1 from tfundinfo fi where fi.c_fundcode=b.c_fundcode and instr('''|| v_InterFilterMangerType ||''', nvl(fi.c_mangertype,0))>0) '
       else null
       end
       using  p_ddate;
    else
    begin
    if v_min_cdate_fundagency=v_max_cdate_fundagency then
       execute immediate '
       insert into topenfund_statistics(d_date,zfe,gefe,grgpfe,grhhfe,grzqfe, grhbfe,grqdfe,
                                        jgfe,jggpfe,jghhfe,jgzqfe, jghbfe,jgqdfe,
                                        zxfe,yhfe,qszfe,zqzxjgfe,zyxsjgfe,zje,
                                        gezje,grgpje, grhhje,grzqje, grhbje,grqdje,
                                        jgzje,jggpje,jghhje,jgzqje,jghbje,jgqdje,
                                        zxzje,yhzje,qszje,zqzxjgje,zyxsjgje)
       select :1,
              nvl(sum(f_realshares),0) zfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_realshares,0)),0) gefe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_gprealshares,0)),0) grgpfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_hhrealshares,0)),0) grhhfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_zqrealshares,0)),0) grzqfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_hbrealshares,0)),0) grhbfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_qdrealshares,0)),0) grqdfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_realshares)),0) jgfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_gprealshares)),0) jggpfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_hhrealshares)),0) jghhfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_zqrealshares)),0) jgzqfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_hbrealshares)),0) jghbfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_qdrealshares)),0) jgqdfe,

              nvl(sum(decode(b.c_agencytype,''1'',0,''2'',0,''4'',0,''5'',0,b.f_realshares)),0) zxfe,
              nvl(sum(decode(b.c_agencytype,''1'',b.f_realshares,0)),0) yhfe,
              nvl(sum(decode(b.c_agencytype,''2'',b.f_realshares,0)),0) qszfe,
              nvl(sum(decode(b.c_agencytype,''4'',b.f_realshares,0)),0) zqzxjgfe,
              nvl(sum(decode(b.c_agencytype,''5'',b.f_realshares,0)),0) zyxsjgfe,
              nvl(round(sum(b.f_realsum),2),0) zje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_realsum,0)),2),0) gezje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_gprealsum,0)),2),0) grgpje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_hhrealsum,0)),2),0) grhhje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_zqrealsum,0)),2),0) grzqje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_hbrealsum,0)),2),0) grhbje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_qdrealsum,0)),2),0) grqdje,
              nvl(round(sum(b.f_realsum),2),0)-nvl(round(sum(decode(b.c_custtype,''1'',b.f_realsum,0)),2),0) jgzje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_gprealsum)),2),0) jggpje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_hhrealsum)),2),0) jghhje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_zqrealsum)),2),0) jgzqje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_hbrealsum)),2),0) jghbje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_qdrealsum)),2),0) jgqdje,
              nvl(round(sum(decode(b.c_agencytype,''1'',0,''2'',0,''4'',0,''5'',0,b.f_realsum)),2),0) zxzje,
              nvl(round(sum(decode(b.c_agencytype,''1'',b.f_realsum,0)),2),0) yhzje,
              nvl(round(sum(decode(b.c_agencytype,''2'',b.f_realsum,0)),2),0) qszje,
              nvl(round(sum(decode(b.c_agencytype,''4'',b.f_realsum,0)),2),0) zqzxjgje,
              nvl(round(sum(decode(b.c_agencytype,''5'',b.f_realsum,0)),2),0) zyxsjgje
       from   tsharecurrents_tmp_all b,tfundinfo tfi
       where  b.f_realshares      > 0
       and    b.d_cdate          <= :2
       and    b.d_sharevaliddate  > :3
       and    b.c_fundacco       != ''996000000000''
       and    b.c_fundcode   not in (''206101'',''206102'',''489057'',''489058'')
       and    b.c_fundcode=tfi.c_fundcode
       and    tfi.c_RptIsSend=''1''
       and    instr('''|| v_ReportUnSendFundCode ||''', b.c_fundcode)=0 ' ||
       case when v_InterfaceMangerClass ='1' then
                 ' and not exists(select 1 from tfundinfo fi where fi.c_fundcode=b.c_fundcode and instr('''|| v_InterFilterMangerType ||''', nvl(fi.c_mangertype,0))>0) '
       else null
       end
       using  p_ddate,v_min_cdate_fundagency,v_min_cdate_fundagency;
    else
       execute immediate '
       insert into topenfund_statistics(
                                        d_date,zfe,gefe,grgpfe,grhhfe,grzqfe, grhbfe,grqdfe,
                                        jgfe,jggpfe,jghhfe,jgzqfe, jghbfe,jgqdfe,
                                        zxfe,yhfe,qszfe,zqzxjgfe,zyxsjgfe,zje,
                                        gezje,grgpje, grhhje,grzqje, grhbje,grqdje,
                                        jgzje,jggpje,jghhje,jgzqje,jghbje,jgqdje,
                                        zxzje,yhzje,qszje,zqzxjgje,zyxsjgje)
       select :1,
              nvl(sum(f_realshares),0) zfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_realshares,0)),0) gefe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_gprealshares,0)),0) grgpfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_hhrealshares,0)),0) grhhfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_zqrealshares,0)),0) grzqfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_hbrealshares,0)),0) grhbfe,
              nvl(sum(decode(b.c_custtype,''1'',b.f_qdrealshares,0)),0) grqdfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_realshares)),0) jgfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_gprealshares)),0) jggpfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_hhrealshares)),0) jghhfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_zqrealshares)),0) jgzqfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_hbrealshares)),0) jghbfe,
              nvl(sum(decode(b.c_custtype,''1'',0,b.f_qdrealshares)),0) jgqdfe,
              nvl(sum(decode(b.c_agencytype,''1'',0,''2'',0,''4'',0,''5'',0,b.f_realshares)),0) zxfe,
              nvl(sum(decode(b.c_agencytype,''1'',b.f_realshares,0)),0) yhfe,
              nvl(sum(decode(b.c_agencytype,''2'',b.f_realshares,0)),0) qszfe,
              nvl(sum(decode(b.c_agencytype,''4'',b.f_realshares,0)),0) zqzxjgfe,
              nvl(sum(decode(b.c_agencytype,''5'',b.f_realshares,0)),0) zyxsjgfe,
              nvl(round(sum(b.f_realsum),2),0) zje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_realsum,0)),2),0) gezje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_gprealsum,0)),2),0) grgpje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_hhrealsum,0)),2),0) grhhje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_zqrealsum,0)),2),0) grzqje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_hbrealsum,0)),2),0) grhbje,
              nvl(round(sum(decode(b.c_custtype,''1'',b.f_qdrealsum,0)),2),0) grqdje,
              nvl(round(sum(b.f_realsum),2),0)-nvl(round(sum(decode(b.c_custtype,''1'',b.f_realsum,0)),2),0) jgzje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_gprealsum)),2),0) jggpje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_hhrealsum)),2),0) jghhje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_zqrealsum)),2),0) jgzqje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_hbrealsum)),2),0) jghbje,
              nvl(round(sum(decode(b.c_custtype,''1'',0,b.f_qdrealsum)),2),0) jgqdje,
              nvl(round(sum(decode(b.c_agencytype,''1'',0,''2'',0,''4'',0,''5'',0,b.f_realsum)),2),0) zxzje,
              nvl(round(sum(decode(b.c_agencytype,''1'',b.f_realsum,0)),2),0) yhzje,
              nvl(round(sum(decode(b.c_agencytype,''2'',b.f_realsum,0)),2),0) qszje,
              nvl(round(sum(decode(b.c_agencytype,''4'',b.f_realsum,0)),2),0) zqzxjgje,
              nvl(round(sum(decode(b.c_agencytype,''5'',b.f_realsum,0)),2),0) zyxsjgje
       from   tsharecurrents_tmp_all b,tfundinfo tfi
       where  b.f_realshares      > 0
       and    b.d_cdate          <= pkg_Openfund_BuyRedeemSum.func_fundagency_cdate(b.c_fundcode||b.c_agencyno)
       and    b.d_sharevaliddate  > pkg_Openfund_BuyRedeemSum.func_fundagency_cdate(b.c_fundcode||b.c_agencyno)
       and    b.c_fundacco       != ''996000000000''
       and    b.c_fundcode   not in (''206101'',''206102'',''489057'',''489058'')
       and    b.c_fundcode=tfi.c_fundcode
       and    tfi.c_RptIsSend=''1''
       and    instr('''|| v_ReportUnSendFundCode ||''', b.c_fundcode)=0 ' ||
       case when v_InterfaceMangerClass ='1' then
                 ' and not exists(select 1 from tfundinfo fi where fi.c_fundcode=b.c_fundcode and instr('''|| v_InterFilterMangerType ||''', nvl(fi.c_mangertype,0))>0) '
       else null
       end
       using  p_ddate;
    end if;
    end;
    end if;

    ------------------------------------------------------------------------------------------------
    -- 10. 统计各类有效账户数
    ------------------------------------------------------------------------------------------------
    -- 10.1 统计总有效账户数、个人有效账户总数，机构有效账户总数
    ------------------------------------------------------------------------------------------------
    execute immediate '
    update topenfund_statistics
    set    (jjzhzs,grs,jgs)=(select count(*),
                                    count(decode(c_custtype,''1'',1,null)),
                                    count(decode(c_custtype,''1'',null,1))
                             from   tvalidacco)
    where  d_date=:1'
    using  p_ddate;

    ------------------------------------------------------------------------------------------------
    -- 10.2 统计有效个人账户总数，有效机构账户总数
    ------------------------------------------------------------------------------------------------
    if v_min_cdate_fundagency=v_max_cdate_fundagency then
        execute immediate '
        update topenfund_statistics
        set    (yxgrs,yxjgs)=(select validategr,validatejg
                              from   (select count(decode(c_custtype,''1'',null,1)) validatejg,
                                             count(decode(c_custtype,''1'',1,null)) validategr
                                      from   (select b.c_fundacco,b.c_custtype
                                              from   tsharecurrents_tmp_all b,tfundinfo tfi
                                              where  b.f_realshares      > 0
                                              and    b.d_cdate          <= :1
                                              and    b.d_sharevaliddate  > :2
                                              and    b.c_fundacco       != ''996000000000''
                                              and    b.c_fundcode   not in (''206101'',''206102'',''489057'',''489058'')
                                              and    b.c_fundcode = tfi.c_fundcode
                                              and    tfi.c_RptIsSend = ''1''
                                              and    instr('''|| v_ReportUnSendFundCode ||''', b.c_fundcode)=0 ' ||
                                              case when v_InterfaceMangerClass ='1' then
                                                        ' and not exists(select 1 from tfundinfo fi where fi.c_fundcode=b.c_fundcode and instr('''|| v_InterFilterMangerType ||''', nvl(fi.c_mangertype,0))>0) '
                                              else null
                                              end  ||
                                              ' group  by b.c_fundacco,b.c_custtype)))
        where  d_date=:3'
        using  v_min_cdate_fundagency,v_min_cdate_fundagency,p_ddate;
    else
        execute immediate '
        update topenfund_statistics
        set    (yxgrs,yxjgs)=(select validategr,validatejg
                              from   (select count(decode(c_custtype,''1'',null,1)) validatejg,
                                             count(decode(c_custtype,''1'',1,null)) validategr
                                      from   (select b.c_fundacco,b.c_custtype
                                              from   tsharecurrents_tmp_all b,tfundinfo tfi
                                              where  b.f_realshares      > 0
                                              and    b.d_cdate          <= pkg_Openfund_BuyRedeemSum.func_fundagency_cdate(b.c_fundcode||b.c_agencyno)
                                              and    b.d_sharevaliddate  > pkg_Openfund_BuyRedeemSum.func_fundagency_cdate(b.c_fundcode||b.c_agencyno)
                                              and    b.c_fundacco       != ''996000000000''
                                              and    b.c_fundcode   not in (''206101'',''206102'',''489057'',''489058'')
                                              and    b.c_fundcode = tfi.c_fundcode
                                              and    tfi.c_RptIsSend = ''1''
                                              and    instr('''|| v_ReportUnSendFundCode ||''', b.c_fundcode)=0 ' ||
                                              case when v_InterfaceMangerClass ='1' then
                                                        ' and not exists(select 1 from tfundinfo fi where fi.c_fundcode=b.c_fundcode and instr('''|| v_InterFilterMangerType ||''', nvl(fi.c_mangertype,0))>0) '
                                              else null
                                              end  ||
                                              ' group  by b.c_fundacco,b.c_custtype)))
        where  d_date=:1'
        using  p_ddate;
    end if;
    ------------------------------------------------------------------------------------------------
    -- 10.3 统计有效且累计份额余额是0的账户总数
    ------------------------------------------------------------------------------------------------
    if v_min_cdate_fundagency=v_max_cdate_fundagency then
       execute immediate '
       update topenfund_statistics
       set    yjys = (select count(*)
                      from   (select /*+ ordered use_merge(a,b) */
                                     b.c_fundacco,b.c_custtype
                              from   tvalidacco a,tsharecurrents_tmp_all b,tfundinfo tfi
                              where  a.c_fundacco        = b.c_fundacco
                              and    b.d_cdate          <= :1
                              and    b.d_sharevaliddate  > :2
                              and    b.c_fundacco       != ''996000000000''
                              and    b.c_fundcode   not in (''206101'',''206102'',''489057'',''489058'')
                              and    b.c_fundcode = tfi.c_fundcode
                              and    tfi.c_RptIsSend = ''1''
                              and    instr('''|| v_ReportUnSendFundCode ||''', b.c_fundcode)=0 ' ||
                              case when v_InterfaceMangerClass ='1' then
                                        ' and not exists(select 1 from tfundinfo fi where fi.c_fundcode=b.c_fundcode and instr('''|| v_InterFilterMangerType ||''', nvl(fi.c_mangertype,0))>0) '
                              else null
                              end  ||
                              ' group  by b.c_fundacco,b.c_custtype
                              having sum(b.f_realshares) = 0))
       where  d_date=:3'
       using  v_min_cdate_fundagency,v_min_cdate_fundagency,p_ddate;
    else
       execute immediate '
       update topenfund_statistics
       set    yjys = (select count(*)
                      from   (select /*+ ordered use_merge(a,b) */
                                     b.c_fundacco,b.c_custtype
                              from   tvalidacco a,tsharecurrents_tmp_all b,tfundinfo tfi
                              where  a.c_fundacco        = b.c_fundacco
                              and    b.d_cdate          <= pkg_Openfund_BuyRedeemSum.func_fundagency_cdate(b.c_fundcode||b.c_agencyno)
                              and    b.d_sharevaliddate  > pkg_Openfund_BuyRedeemSum.func_fundagency_cdate(b.c_fundcode||b.c_agencyno)
                              and    b.c_fundacco       != ''996000000000''
                              and    b.c_fundcode   not in (''206101'',''206102'',''489057'',''489058'')
                              and    b.c_fundcode = tfi.c_fundcode
                              and    tfi.c_RptIsSend = ''1''
                              and    instr('''|| v_ReportUnSendFundCode ||''', b.c_fundcode)=0 ' ||
                              case when v_InterfaceMangerClass ='1' then
                                        ' and not exists(select 1 from tfundinfo fi where fi.c_fundcode=b.c_fundcode and instr('''|| v_InterFilterMangerType ||''', nvl(fi.c_mangertype,0))>0) '
                              else null
                              end  ||
                              ' group  by b.c_fundacco,b.c_custtype
                              having sum(b.f_realshares) = 0))
       where  d_date=:1'
       using  p_ddate;
    end if;
    ------------------------------------------------------------------------------------------------
    -- 10.4 算出有效账户总数、有效且累计份额余额>0的账户总数
    ------------------------------------------------------------------------------------------------
    update topenfund_statistics
    set    yxzhzs = yxgrs + yxjgs,
           wjys   = jjzhzs - (yxgrs + yxjgs) - yjys
    where  d_date = p_ddate;
    commit;

    ------------------------------------------------------------------------------------------------
    -- 11 清除哈希, 删除临时表 tvalidacco,tsharecurrents_tmp_all
    ------------------------------------------------------------------------------------------------
    pkg_Openfund_BuyRedeemSum.v_hash_agency.delete();
    pkg_Openfund_BuyRedeemSum.v_hash_fundagency.delete();
    pkg_Openfund_BuyRedeemSum.v_hash_netvalue.delete();
    pkg_Openfund_BuyRedeemSum.v_hash_lastshares.delete();
    pkg_Openfund_BuyRedeemSum.v_hash_lastasset.delete();
    pkg_Openfund_BuyRedeemSum.v_hash_holddate.delete();
    pkg_Openfund_BuyRedeemSum.v_hash_agencytype.delete();
    pkg_Openfund_BuyRedeemSum.v_hash_fundprop.delete();
    pkg_Openfund_BuyRedeemSum.v_hash_exchangerate.delete();

    for t in (select 'truncate table '||table_name trun_tbl,'drop table '||table_name drop_tbl
              from   user_tables
              where  table_name in (upper('tvalidacco'),
                                    upper('tsharecurrents_tmp_all'))) loop
        execute immediate t.trun_tbl;
        execute immediate t.drop_tbl;
    end loop;
  end;

end;

/

