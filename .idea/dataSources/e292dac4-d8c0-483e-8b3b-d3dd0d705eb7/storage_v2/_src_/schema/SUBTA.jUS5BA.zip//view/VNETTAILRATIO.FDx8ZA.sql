create view VNETTAILRATIO as
  select c_fundcode, c_agencyno, c_regioncode, c_custtype, c_updateflag,
       f_sharemin, f_sharemax, f_ratiomin,   f_ratiomax,
       f_ratio,    c_cacltype, d_begindate,F_AGERATIO,F_NETRATIO,
       last_value(d_enddate) over(partition by c_fundcode, c_agencyno, c_regioncode, c_custtype, d_begindate
                                      order by d_enddate rows between unbounded preceding
                                                                  and unbounded following) d_enddate
  from (select c_fundcode, c_agencyno, c_regioncode, c_custtype, c_updateflag,
               f_sharemin, f_sharemax, f_ratiomin,   f_ratiomax,
               f_ratio,    c_cacltype, d_begindate,F_AGERATIO,F_NETRATIO,
               nvl(lead(d_begindate) over(partition by c_fundcode, c_agencyno, c_regioncode, c_custtype
                                              order by d_begindate, f_sharemin),
               to_date('20991231', 'yyyymmdd')) d_enddate
          from tnettailratio)
/

