create FUNCTION FChangeIdentityNo (v_IDCard IN VARCHAR2)
RETURN VARCHAR2
AS
 m_NewIDCard VARCHAR2(18);
 m_StrLengthB NUMBER;
 m_StrLength NUMBER;
 m_Num  NUMBER;
 m_iCount NUMBER;
 m_Code  CHAR(1);
 m_CodeTmp CHAR(1);
BEGIN
 m_StrLength := LENGTH(TRIM(v_IDCard));
 m_StrLengthB := LENGTHB(TRIM(v_IDCard));

 IF m_StrLength = 15 and m_StrLengthB = 15 THEN     --???15????,????18????
  --??????????'19'
  m_NewIDCard := SUBSTR(TRIM(v_IDCard),1,6) || '19' || SUBSTR(TRIM(v_IDCard),7,9);

  --?????
  m_Num := 0;
  FOR m_iCount IN 2..18 LOOP
   m_CodeTmp := SUBSTR(m_NewIDCard,19 - m_iCount,1);
   if ASCII(m_CodeTmp)>=48 AND ASCII(m_CodeTmp)<=57 THEN
     m_Num := m_Num + MOD(POWER(2,m_iCount - 1),11) * TO_NUMBER(m_CodeTmp);
   ELSE
     RETURN v_IDCard;
   END IF;
  END LOOP;

  m_Num := MOD(m_Num,11);

  IF m_Num = 0 THEN
   m_Code := '1';
  ELSIF m_Num = 1 THEN
   m_Code := '0';
  ELSIF m_Num = 2 THEN
   m_Code := 'X';
  ELSE
   m_Code := TO_CHAR(12 - m_Num);
  END IF;

  RETURN TRIM(m_NewIDCard) || TRIM(m_Code);
 ELSE            -- ??????15??????
  RETURN v_IDCard;
 END IF;
END FChangeIdentityNo;


/

