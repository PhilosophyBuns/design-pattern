create PROCEDURE pStructMdf(sTable1 VARCHAR2,sTable2 VARCHAR2,nModified OUT NUMBER)
AS
	nMdf	NUMBER;
	nMdfd	NUMBER;
BEGIN
	nMdf := 0;
    SELECT COUNT(*) INTO nMdf FROM TAB
    	WHERE TNAME = sTable2;
    nMdf := nMdf + 1;
	pColMdf(sTable1,sTable2,nMdf,nMdfd);
	nModified := nMdfd;
	IF nMdf != 1 THEN
		pColMdf(sTable1,sTable2,3,nMdfd);
		IF nModified = 0 THEN
			nModified := nMdfd;
		END IF;
	END IF;
END pStructMdf;
/

