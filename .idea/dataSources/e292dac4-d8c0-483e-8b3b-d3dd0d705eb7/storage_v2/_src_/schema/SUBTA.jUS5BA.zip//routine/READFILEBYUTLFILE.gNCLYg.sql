create PROCEDURE READFILEBYUTLFILE (
  p_logdir varchar2,
  p_logfile varchar2
)
is
  v_handle utl_file.file_type;
  v_text varchar2(1024);
  v_index_no integer;
begin

  begin
  delete from tdatapumplogfile;
  end;

  v_index_no := 0;
  v_handle := utl_file.fopen(location => p_logdir,filename => p_logfile,open_mode => 'r');
  loop
    begin
      utl_file.get_line(v_handle,v_text);
      v_text := Trim(v_text);
      v_index_no := v_index_no +1 ;

      begin
      insert into tdatapumplogfile values (v_text,v_index_no);
      end;

    exception
    when no_data_found then
         exit;
    end ;
  end loop;

  utl_file.fclose(v_handle);

end;

/

