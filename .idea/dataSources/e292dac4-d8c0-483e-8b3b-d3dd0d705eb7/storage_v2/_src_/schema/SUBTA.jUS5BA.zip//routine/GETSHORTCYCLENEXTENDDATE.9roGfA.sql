create function GetShortCycleNextEndDate(fundcode    in varchar2,
                                                    regDate     in varchar2,
                                                    nowEndDate  in varchar2,
                                                    callType    in varchar2 := '0',
                                                    nextFlag    in varchar2 := '0')
  return varchar2 as
  m_calEnddate varchar2(8);
  m_nextdate   varchar2(8);
  m_cycletype  char(1);
  m_cyclestep  integer;
  m_chdate     date;
  m_isworkdate integer;
  m_autoInc    integer;
  m_afmonth    integer;
  m_afYear     integer;
  vsetupdate   varchar2(8);
  m_oriSource  char(1);
  vconfirmdate varchar2(8);
  vstartdate   varchar2(8);
  workdayflag  integer;
begin

  begin
    select c_cycletype, l_cyclestep
      into m_cycletype, m_cyclestep
      from tshortcyclefinance
     where c_fundcode = fundcode;
  exception
    when no_data_found then
      return - 1;
  end;

  select to_char(d_setupdate, 'YYYYMMDD') into  vsetupdate
    from tfundinfo a
   where a.c_fundcode = fundcode;

  if regDate > vsetupdate and regDate = nowEndDate  then
    m_orisource := '1';
  else
    m_orisource := '0';
  end if;
  /*判断是否是工作日*/
  workdayflag := 0;
  vstartdate := nowEndDate;
  select count(1) into workdayflag from topenday a where d_date = to_date(nowEndDate,'YYYYMMDD') and a.l_workflag='1';
  if workdayflag = 0 then
    vstartdate := getrealdays(fundcode, '***',nowEndDate,1);
  end if;
  /*计算到期日期和确认日*/
  if m_orisource = '0' then
    m_calEnddate := getrealdays(fundcode, '***', vstartdate, 0);
  else
    m_calEnddate := getrealdays(fundcode, '***', vstartdate, -1);
  end if;

  if calltype = '0' then
    m_autoInc := 1;
  else
    m_autoInc := 0;
  end if;

  /*计算出跨度*/
  /*然后根据跨度计算出兑付日期*/
  if m_cycletype = '0' then
    m_afMonth  := to_number(substr(m_calEnddate, 5, 2)) +
                  m_autoInc * m_cyclestep;
    m_afYear   := to_number(substr(m_calEnddate, 1, 4));
    while (m_afMonth > 12) loop
      m_afYear  := m_afYear + 1;
      m_afMonth := m_afMonth - 12;
    end loop;
    m_nextdate := to_char(m_afYear) || lpad(to_char(m_afMonth), 2, '0') ||
                    substr(m_calEnddate, 7, 2);

    begin
      m_chdate := to_date(m_nextdate, 'yyyymmdd');
    exception
      when others THEN
        m_afMonth := m_afMonth + 1;
        if m_afMonth > 12 THEN
          m_afYear  := m_afYear + 1;
          m_afMonth := m_afMonth - 12;
        end if;
        m_chdate := to_date(to_char(m_afYear) ||
                            lpad(to_char(m_afMonth), 2, '0') || '01',
                            'yyyymmdd');
    end;

  else
    m_chdate   := to_date(m_calEnddate, 'yyyymmdd') +
                  m_autoInc * m_cyclestep;
  end if;

  begin
    select a.l_workflag
      into m_isworkdate
      from topenday a
     where d_date = m_chdate;

  exception when no_data_found then
    m_chdate := to_date('20991231','yyyymmdd');
    m_isworkdate := 1;
  end;

  if m_isworkdate = 0 then
    m_chdate := to_date(getrealdays(fundcode,
                                    '***',
                                    to_char(m_chdate, 'yyyymmdd'),
                                    1),
                        'yyyymmdd');
  end if;
  /*获取系统确认日期*/
  select t.c_value into vconfirmdate from tsysparameter t where t.c_class = 'System' and t.c_item = 'SysDate';
  /*如果取下一个到期日等于确认日期的话，就重新推一个周期*/
  if (to_char(m_chdate,'YYYYMMDD') <= vconfirmdate) and (nextFlag ='0') then
    m_calEnddate := getrealdays(fundcode, '***', to_char(m_chdate,'YYYYMMDD'), 0);

    if calltype = '0' then
      m_autoInc := 1;
    else
      m_autoInc := 0;
    end if;

    /*计算出跨度*/
    /*然后根据跨度计算出兑付日期*/
    if m_cycletype = '0' then
      m_afMonth  := to_number(substr(m_calEnddate, 5, 2)) +
                  m_autoInc * m_cyclestep;
      m_afYear   := to_number(substr(m_calEnddate, 1, 4));
    while (m_afMonth > 12) loop
      m_afYear  := m_afYear + 1;
      m_afMonth := m_afMonth - 12;
    end loop;
    m_nextdate := to_char(m_afYear) || lpad(to_char(m_afMonth), 2, '0') ||
                    substr(m_calEnddate, 7, 2);

    begin
      m_chdate := to_date(m_nextdate, 'yyyymmdd');
    exception
      when others THEN
        m_afMonth := m_afMonth + 1;
        if m_afMonth > 12 THEN
          m_afYear  := m_afYear + 1;
          m_afMonth := m_afMonth - 12;
        end if;
        m_chdate := to_date(to_char(m_afYear) ||
                            lpad(to_char(m_afMonth), 2, '0') || '01',
                            'yyyymmdd');
    end;

    else
      m_chdate   := to_date(m_calEnddate, 'yyyymmdd') +
                  m_autoInc * m_cyclestep;
    end if;

    begin
      select a.l_workflag
        into m_isworkdate
        from topenday a
       where d_date = m_chdate;

    exception when no_data_found then
      m_chdate := to_date('20991231','yyyymmdd');
      m_isworkdate := 1;
    end;

    if m_isworkdate = 0 then
      m_chdate := to_date(getrealdays(fundcode,
                                    '***',
                                    to_char(m_chdate, 'yyyymmdd'),
                                    1),
                        'yyyymmdd');
    end if;
  end if;
  return to_char(m_chdate, 'yyyymmdd');

end;

/

