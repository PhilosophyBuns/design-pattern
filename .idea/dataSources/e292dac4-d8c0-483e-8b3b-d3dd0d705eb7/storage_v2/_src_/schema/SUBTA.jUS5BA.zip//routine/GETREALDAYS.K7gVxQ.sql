create function GetRealDays(v_fundcode IN VARCHAR2,v_agencyno IN VARCHAR2,v_currentdate IN VARCHAR2,n_offset IN NUMBER)
return varchar2 is
  Result varchar2(8);
  sWorkType CHAR(1);
  sProperty CHAR(1);
begin
    if n_offset=0 then
       return(v_currentdate);
    end if;

    sWorkType :='1';

    begin
        select decode(nvl(c_raisetype,c_property),'6','6',c_property)
        into sProperty
        from tfundinfo
        where c_fundcode=v_fundcode;
    exception when no_data_found then
	    sProperty :='0';
    end;

    begin
        select C_WORKTYPE
        into sWorkType
        from tfundagency
        where c_fundcode=v_fundcode
          and c_agencyno=v_agencyno;
    exception when no_data_found then sWorkType :='1';
    end;
    if sProperty = '6' then
        if n_offset>0 then
            select to_char(max(d_date),'yyyymmdd')
            into Result
            from
                (select d_date from tqdopenday
                 where c_fundcode=v_fundcode and
                   (d_date=to_date(v_currentdate,'yyyymmdd')
                   or
                   ((l_workflag='1' or  l_workflag=decode(sWorkType,'2',1,2))
                     and d_date>=to_date(v_currentdate,'yyyymmdd')))
                 order by d_date asc)
            where rownum<=abs(n_offset)+1;
        else
            select to_char(min(d_date),'yyyymmdd')
            into Result
            from
                (select d_date from tqdopenday
                 where c_fundcode=v_fundcode and
                   (d_date=to_date(v_currentdate,'yyyymmdd')
                   or
                   ((l_workflag='1' or  l_workflag=decode(sWorkType,'2',1,2))
                     and d_date<=to_date(v_currentdate,'yyyymmdd')))
                 order by d_date desc)
            where rownum<=abs(n_offset)+1;
        end if;
    else
        if n_offset>0 then
            select to_char(max(d_date),'yyyymmdd')
            into Result
            from
                (select d_date from topenday
                 where
                   d_date=to_date(v_currentdate,'yyyymmdd')
                   or
                   ((l_workflag='1' or  l_workflag=decode(sWorkType,'2',1,2))
                     and d_date>=to_date(v_currentdate,'yyyymmdd'))
                 order by d_date asc)
            where rownum<=abs(n_offset)+1;
        else
            select to_char(min(d_date),'yyyymmdd')
            into Result
            from
                (select d_date from topenday
                 where
                   d_date=to_date(v_currentdate,'yyyymmdd')
                   or
                   ((l_workflag='1' or  l_workflag=decode(sWorkType,'2',1,2))
                     and d_date<=to_date(v_currentdate,'yyyymmdd'))
                 order by d_date desc)
            where rownum<=abs(n_offset)+1;
        end if;
    end if;

    return(Result);
end GetRealDays;

/

