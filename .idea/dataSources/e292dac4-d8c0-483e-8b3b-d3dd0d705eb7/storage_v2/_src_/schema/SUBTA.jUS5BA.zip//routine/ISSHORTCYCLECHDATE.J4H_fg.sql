create function IsShortCycleChDate(fundcode in varchar2,regDate in varchar2,oriSource in varchar2,cfmDate in varchar2)
return integer
as
  m_hold integer;
  m_orisource char(1);
begin

  select to_char(count(*)) into m_orisource
    from tfundinfo a
   where regdate > to_char(a.d_setupdate,'yyyymmdd')
     and a.c_fundcode = fundcode;

  if m_orisource = '0' then
        if getrealdays(fundcode,'***',cfmDate,-1) = regDate then
            return 0;
        end if;
    else
        if regDate = cfmDate then
            return 0;
        end if;
    end if;

  select getshortcyclehold(fundcode,regDate,m_orisource,cfmDate) into m_hold from dual;
  if m_hold = 0 then
        return 1;
    else
        return 0;
  end if;

end;


/

