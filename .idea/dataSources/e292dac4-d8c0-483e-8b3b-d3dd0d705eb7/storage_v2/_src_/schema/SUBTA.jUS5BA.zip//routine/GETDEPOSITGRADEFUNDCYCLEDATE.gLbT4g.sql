create FUNCTION GetDepositGradeFundCycleDate(pRegDate   IN DATE,
                                                        pCycleDays IN INTEGER,
                                                        pCfmDate   IN DATE)
  RETURN DATE
/*author: jiangzj--蒋征建
  *   date: 2012-11-22
  *新增Oracle函数，用于获取保证金子产品到期日期：
  *1、输入参数：份额注册日期、周期天数、系统确认日期
  *2、输出参数：最近一次到期日期
  *3、周期按自然日计算
  *
  * Example：
  * 1、SELECT GetDepositGradeFundCycleDate(TO_DATE('20121122', 'yyyymmdd'), 8, TO_DATE('20121120', 'yyyymmdd')) FROM dual d
  * 2、SELECT GetDepositGradeFundCycleDate(TO_DATE('20121122', 'yyyymmdd'), 8, TO_DATE('20121208', 'yyyymmdd')) FROM dual d
  * 3、SELECT GetDepositGradeFundCycleDate(TO_DATE('20121122', 'yyyymmdd'), 8, TO_DATE('20121218', 'yyyymmdd')) FROM dual d */
 IS
  vResult  DATE;
  vRegDate DATE := TRUNC(pRegDate);
  vCfmDate DATE := TRUNC(pCfmDate);
BEGIN
  IF (pCycleDays <= 0) THEN
    RAISE_APPLICATION_ERROR(-20008, '周期天数必须大于0！');
  END IF;

  /*如果到期日期均大于确认日期，则到期日期赋值为份额注册日期*/
  IF vRegDate + pCycleDays > vCfmDate THEN
    vResult := vRegDate;
  ELSE
    /*最近一次到期日期，指小于等于确认日期的到期日期*/
    vResult := vRegDate +
               TRUNC((vCfmDate - vRegDate) / pCycleDays) * pCycleDays;
  END IF;
  RETURN vResult;
END;


/

