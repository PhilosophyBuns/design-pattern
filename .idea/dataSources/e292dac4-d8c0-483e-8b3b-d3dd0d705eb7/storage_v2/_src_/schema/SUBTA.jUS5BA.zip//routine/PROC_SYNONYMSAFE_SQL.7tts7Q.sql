create procedure proc_synonymsafe_sql(p_executesql varchar2)
as
v_error integer;
begin
  begin
    execute immediate p_executesql;
  exception when others then v_error:=1;
  end;
end;


/

