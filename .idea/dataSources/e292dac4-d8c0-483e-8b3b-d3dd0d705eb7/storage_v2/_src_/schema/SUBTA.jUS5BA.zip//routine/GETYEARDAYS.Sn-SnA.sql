create function GetYearDays(sYear IN VARCHAR2)
return varchar2 is
    Result integer;

    nYear integer := 0;
    nDays integer := 365;
begin
    select to_number(sYear) into nYear from dual;

    if( ( (nYear-trunc(nYear/400)*400)=0 ) or ( ( (nYear-trunc(nYear/4)*4)=0 ) and ( (nYear-trunc(nYear/100)*100) <> 0) ) ) then
        nDays := 366;
    end if;

    Result := nDays;
    return(Result);
end;


/

