create FUNCTION GETCHDATE(FUNDCODE   IN VARCHAR2,
                                     ASSIGNTYPE IN VARCHAR2,
                                     CHMONTH    IN INTEGER,
                                     CHDAY      IN INTEGER) RETURN VARCHAR2 IS
  CHDATESTR       VARCHAR2(8);
  CURMONTH        INTEGER;
  REQUESTDATESTR  VARCHAR2(8);
  CONFIRMDATESTR  VARCHAR2(8);
  LASTWORKDATESTR VARCHAR2(8);
  NEXTWORKDATESTR VARCHAR2(8);
  CHDATE          VARCHAR2(8);
  LASTDAY         VARCHAR2(8);
  FUNDSTATUS      CHAR(1);
  CHFUNDSTATUS    VARCHAR2(16);

  vcTACode        tsysparameter.c_value%type;
BEGIN
  /* 取系统确认日期 系统申请日期*/
  SELECT TRIM(C_VALUE)
    INTO CONFIRMDATESTR
    FROM TSYSPARAMETER
   WHERE C_ITEM = 'SysDate';

  select nvl(max(a.c_value), 'XX')
    into vcTACode
    from tsysparameter a
   where a.c_item='TACode';

  REQUESTDATESTR := GETREALDAYS(FUNDCODE, 'NVL', CONFIRMDATESTR, -1);

  /*ASSIGNTYPE 8 每日结转*/
  IF (ASSIGNTYPE = '8') THEN
    BEGIN
      CHDATESTR := REQUESTDATESTR;
    END;
  /*ASSIGNTYPE 6、7 按指定日期结转*/
  ELSIF (ASSIGNTYPE = '6') OR (ASSIGNTYPE = '7') THEN
    BEGIN
      BEGIN
          SELECT TO_CHAR(D_CHDATE,'YYYYMMDD')
            INTO CHDATE
            FROM TQSSPECIALPRODUCT
           WHERE C_FUNDCODE = FUNDCODE;
          EXCEPTION
           WHEN NO_DATA_FOUND THEN
             CHDATE := '20010101';
      END;
      IF CHDATE = '20010101' THEN
        BEGIN
          CHDATESTR := '20010101';
        END;
      ELSE
        BEGIN
          CHDATESTR := GETREALDAYS(FUNDCODE, 'NVL', GETREALDAYS(FUNDCODE, 'NVL', CHDATE, -1), 1);
        END;
      END IF;
    END;
  /*ASSIGNTYPE 2 按开放周期结转*/
  ELSIF ASSIGNTYPE = '2' THEN
    BEGIN
      /*获取昨日基金状态*/
      SELECT C_STATUS
        INTO FUNDSTATUS
        FROM TFUNDDAY
       WHERE C_FUNDCODE = FUNDCODE
         AND D_CDATE = TO_DATE(CONFIRMDATESTR,'YYYYMMDD');

      /*昨日基金状态为正常开放，则当天为开放期*/
      IF (FUNDSTATUS = '1') /* 国泰君安要求：暂停申购也需要做兑付 */
        or (vcTACode = '95' and FUNDSTATUS in ('4')) THEN
        BEGIN
          CHDATESTR := REQUESTDATESTR;
        END;
      ELSE
        BEGIN
          CHDATESTR := '20010101';
        END;
      END IF;
    END;
  /* ASSIGNTYPE 9:每日分配，到期日强赎并结转收益 */
  ELSIF ASSIGNTYPE = '9' THEN
    BEGIN
      SELECT TO_CHAR(MIN(a.d_dealdate), 'yyyymmdd')
        INTO CHDATESTR
        FROM tdealdateinfo a
       WHERE a.c_fundcode = FUNDCODE
         AND a.d_dealdate >= TO_DATE(CONFIRMDATESTR,'YYYYMMDD')
         AND a.c_type = '0';

      IF TRIM(CHDATESTR) IS NOT NULL THEN
        BEGIN
          CHDATESTR := GETREALDAYS(FUNDCODE, 'NVL', GETREALDAYS(FUNDCODE, 'NVL', CHDATESTR, -1), 1);
          CHDATESTR := GETREALDAYS(FUNDCODE, 'NVL', CHDATESTR, -1);
        END;
      ELSE
        BEGIN
          CHDATESTR := '20010101';
        END;
      END IF;
    END;
  /*ASSIGNTYPE A:每日分配，开放赎回时结转 */
  /*ASSIGNTYPE B:每日计算，开放日结转 */
  ELSIF ASSIGNTYPE IN ('A', 'B') THEN
    BEGIN
      /*获取昨日基金状态*/
      SELECT C_STATUS
        INTO FUNDSTATUS
        FROM TFUNDDAY
       WHERE C_FUNDCODE = FUNDCODE
         AND D_CDATE = TO_DATE(CONFIRMDATESTR,'YYYYMMDD');
      /* 1-正常开放 4-暂停申购 */
      IF  ( ASSIGNTYPE = 'A' AND FUNDSTATUS = '4')
        OR( ASSIGNTYPE = 'B' AND FUNDSTATUS IN ('1', '4')) THEN
        BEGIN
          CHDATESTR := REQUESTDATESTR;
        END;
      ELSE
        BEGIN
          CHDATESTR := '20010101';
        END;
      END IF;
    END;
  /*ASSIGNTYPE C:按指定基金状态兑付 */
  ELSIF ASSIGNTYPE = 'C' THEN
    BEGIN
      /*获取昨日基金状态*/
      SELECT C_STATUS
        INTO FUNDSTATUS
        FROM TFUNDDAY
       WHERE C_FUNDCODE = FUNDCODE
         AND D_CDATE = TO_DATE(CONFIRMDATESTR,'YYYYMMDD');

      /*获取兑付指定基金状态*/
      SELECT C_CHFUNDSTATUS
        INTO CHFUNDSTATUS
        FROM TQSSPECIALPRODUCT
       WHERE C_FUNDCODE = FUNDCODE;

       IF (CHFUNDSTATUS IS NOT NULL)
         AND (INSTR(CHFUNDSTATUS,FUNDSTATUS)> 0) THEN
         BEGIN
           CHDATESTR := REQUESTDATESTR;
         END;
       ELSE
         BEGIN
           CHDATESTR := '20010101';
         END;
       END IF;
    END;
  ELSE
    BEGIN
      /* 取收益兑付日所在月份*/
      /*ASSIGNTYPE 0 按月结转*/
      IF ASSIGNTYPE = '0' THEN
        BEGIN
          CURMONTH := TO_NUMBER(TO_CHAR(TO_DATE(REQUESTDATESTR, 'yyyymmdd'),
                                        'MM'));
        END;
      END IF;

      /*ASSIGNTYPE 1 按季结转*/
      IF ASSIGNTYPE = '1' THEN
        BEGIN
          CURMONTH := TO_NUMBER(TO_CHAR(TO_DATE(REQUESTDATESTR, 'yyyymmdd'),
                                        'Q'));
          CURMONTH := (CURMONTH - 1) * 3 + CHMONTH;
        END;
      END IF;
      /* 计算结转日 结转日所在月份最后一天*/
      CHDATE := TRIM(SUBSTR(REQUESTDATESTR, 1, 4)) ||
                TRIM(TO_CHAR(CURMONTH, '00')) || TRIM(TO_CHAR(CHDAY, '00'));

      LASTDAY := TO_CHAR(LAST_DAY(TO_DATE((TRIM(SUBSTR(REQUESTDATESTR, 1, 4)) ||
                                          TRIM(TO_CHAR(CURMONTH, '00')) || '15'),
                                          'yyyymmdd')),
                         'yyyymmdd');

      /*计算出的收益兑付日期和当月最后一天比较，如果大于当月最后一天，则取下月第一天为收益兑付日期*/
      IF ROUND(TO_NUMBER(CHDATE) - TO_NUMBER(LASTDAY)) > 0 THEN
        BEGIN
          CHDATE := TO_CHAR(LAST_DAY(TO_DATE(LASTDAY, 'yyyymmdd')) + 1,
                            'yyyymmdd');
        END;
      END IF;

      /* 为防止计算出的结转日不为工作日 先取计算出的结转日的上一工作日，根据上一工作日再取下一工作日*/
      /*如果取出的日期是TA系统的第一个工作日 则LASTWORKDATESTR取的不正确 这种异常情况不考虑 */
      LASTWORKDATESTR := GETREALDAYS(FUNDCODE, 'NVL', CHDATE, -1);
      NEXTWORKDATESTR := GETREALDAYS(FUNDCODE, 'NVL', LASTWORKDATESTR, 1);
      CHDATESTR       := NEXTWORKDATESTR;
    END;
  END IF;


  IF CHDATESTR IS NULL THEN
    BEGIN
      CHDATESTR := '20010101';
    END;
  END IF;

  RETURN CHDATESTR;
END;

/

