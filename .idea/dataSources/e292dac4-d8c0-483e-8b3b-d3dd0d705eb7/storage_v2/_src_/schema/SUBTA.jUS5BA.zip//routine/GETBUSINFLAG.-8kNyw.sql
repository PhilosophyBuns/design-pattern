create function GetBusinFlag(sOutBusinflag varchar2, sType integer)
return varchar2
is
  businflag  varchar2(2);
begin
    businflag := '**';
    if sType = 0 then
    begin
      select nvl(c_caption,'**') into businflag from tdictionary a
       where a.l_keyno = 1151
         and c_keyvalue = sOutBusinflag;
      exception when no_data_found then businflag :='**';
    end;
    else
    begin
      select nvl(c_caption,'**') into businflag from tdictionary a
       where a.l_keyno = 1151
         and a.c_english = sOutBusinflag;
      exception when no_data_found then businflag :='**';
    end;
    end if;
    return(businflag);
end GetBusinFlag;


/

