create procedure P_KJClassInterface(expkjmerger in char) is
begin
  delete tKJClassInterface t where t.c_dataflag = '1';

  insert into tKJClassInterface
    (c_fundcode, c_gradecode, c_dataflag, C_ImpKJSplit, c_expkjmerger)
    select a.c_fundcode,
       a.c_gradefund,
       '1' c_dataflag,
       a.C_ImpKJSplit,
       a.c_expkjmerger
  from (select a.c_fundcode,
               a.c_gradefund,
               a.C_ImpKJSplit,
               nvl(a.c_expkjmerger, '1') c_expkjmerger
          from tshareclass a
         where ((nvl(a.c_expkjmerger, '0') = '1' or (expkjmerger = '1' and nvl(a.c_expkjmerger, '0') <> '0') or nvl(a.c_expkjmerger, '0') = expkjmerger) and
               a.c_fundcode <> a.c_gradefund)
            or exists (select 1
                  from tfundinfo t
                 where t.c_fundcode = a.c_gradefund
                   and t.c_longrationfund = '1')
        union
        select distinct a.c_productid c_fundcode,
                        b.c_fundcode c_gradefund,
                        '' C_ImpKJSplit,
                        '1' c_expkjmerger
          from TCYCLEPRODUCT a, TSubCycleProduct b
         where a.c_productid = b.c_productid
           and b.c_productid <> b.c_fundcode
           and nvl(a.c_ismergeaccount, '0') = '1') a
 where not exists
 (select 1
          from tKJClassInterface t
         where t.c_gradecode = a.c_gradefund)
   and (((a.c_gradefund in
       (select a.c_fundcode
             from tdealflag a
            where exists (select 1
                     from tsysparameter
                    where c_item = 'DispartFundDeal'
                      and c_value = '1')
              and a.d_cdate = (select to_date(c_value, 'yyyymmdd')
                                 from tsysparameter
                                where c_item = 'SysDate')
              and nvl(a.c_dealflag, '0') = '0'
           union
           select a.c_fundcode
             from tfundinfo a
            where not exists (select 1
                     from tsysparameter
                    where c_item = 'DispartFundDeal'
                      and c_value = '1')) or
       (exists (select 1
                     from ttaflowlog t1
                    where t1.c_flowcode = 'ExportNetValue'
                      and nvl(t1.c_dealflag, '0') = '1'))) and
       ((select nvl(tt.c_value, 'A')
             from tsysparameter tt
            where tt.c_item = 'OrganRole') = 'A')) or
       (select nvl(tt.c_value, 'A')
           from tsysparameter tt
          where tt.c_item = 'OrganRole') = 'S');

  commit;
end P_KJClassInterface;

/

