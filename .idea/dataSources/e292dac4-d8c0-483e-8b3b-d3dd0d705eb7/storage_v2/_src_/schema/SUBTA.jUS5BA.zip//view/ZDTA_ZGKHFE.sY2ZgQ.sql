create view ZDTA_ZGKHFE as
  select  s.d_lastmodify,
        o.c_custname ,
       s.c_fundacco ,
       s.c_tradeacco,
       s.c_fundcode  ,
       s.f_realshares  f_confirmbalance
  from subta.tcustomerinfo o, subta.TSTATICSHARES s
 where o.c_custno=s.c_fundacco and (s.c_netno='710' or substr(s.c_tradeacco,4,4)='7777')
 and/* s.d_lastmodify=to_date(to_char(sysdate-1, 'YYYY-MM-DD'),'YYYY-MM-DD') and */
 (o.c_custname='国泰君安证券股份有限公司' or o.c_custname='天津中盛海天投资有限公司'
  or  instr(o.c_custname,'定向')>0 --or o.c_custname in( select a.vc_fund_name from trade.tfundinfo@O32.REGRESS.RDBMS.DEV.US.ORACLE.COM a)
  )
 and s.f_realshares > 0
/

