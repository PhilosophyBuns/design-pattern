create FUNCTION GETDEPOSITPRODUCTCHDATE(FUNDCODE IN VARCHAR2)
  RETURN VARCHAR2 IS
  CHDATESTR     VARCHAR2(8);
  CHMONTH       INTEGER;
  CHDAY         INTEGER;
  TMPASSIGNTYPE CHAR(1);
  ASSIGNTYPE    CHAR(1);

  function innergetchdatebyworkday(pFundCode   in varchar2,
                                   pAssignType IN VARCHAR2,
                                   pCHMonth    IN INTEGER,
                                   pCHDay      IN INTEGER) return varchar2 is
    REQUESTDATESTR VARCHAR2(8);
    CONFIRMDATESTR VARCHAR2(8);
    LASTDAY        VARCHAR2(8);
    FIRSTDAY       VARCHAR2(8);
    CURMONTH       INTEGER;
  begin
    /* 取系统确认日期 系统申请日期*/
    SELECT TRIM(C_VALUE)
      INTO CONFIRMDATESTR
      FROM TSYSPARAMETER
     WHERE C_ITEM = 'SysDate';
    REQUESTDATESTR := GETREALDAYS(pFundCode, 'NVL', CONFIRMDATESTR, -1);
    /* 取收益兑付日所在月份*/
    /*ASSIGNTYPE 0 按月结转*/
    IF pAssignType = '0' THEN
      BEGIN
        CURMONTH := TO_NUMBER(TO_CHAR(TO_DATE(REQUESTDATESTR, 'yyyymmdd'),
                                      'MM'));
      END;
    END IF;

    /*ASSIGNTYPE 1 按季结转*/
    IF pAssignType = '1' THEN
      BEGIN
        CURMONTH := TO_NUMBER(TO_CHAR(TO_DATE(REQUESTDATESTR, 'yyyymmdd'),
                                      'Q'));
        CURMONTH := (CURMONTH - 1) * 3 + pCHMonth;
      END;
    END IF;

    FIRSTDAY := TRIM(SUBSTR(REQUESTDATESTR, 1, 4)) ||
                TRIM(TO_CHAR(CURMONTH, '00')) || '01';
    LASTDAY  := TO_CHAR(LAST_DAY(TO_DATE((TRIM(SUBSTR(REQUESTDATESTR, 1, 4)) ||
                                         TRIM(TO_CHAR(CURMONTH, '00')) || '15'),
                                         'yyyymmdd')),
                        'yyyymmdd');
    BEGIN
      select to_char(d_date, 'yyyymmdd')
        into CHDATESTR
        from (select t.d_date, rownum rn
                from topenday t
               where t.d_date >= to_date(FIRSTDAY, 'yyyymmdd')
                 and t.d_date <= to_date(LASTDAY, 'yyyymmdd')
                 and (l_workflag = '1' or l_workflag = '2')
               order by t.d_date asc) a
       where a.rn = pCHDay - 40;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
          select to_char(d_date, 'yyyymmdd')
            into CHDATESTR
            from (select d_date, rownum rn
                    from topenday
                   where (l_workflag = '1' or l_workflag = '2')
                     and d_date > to_date(LASTDAY, 'yyyymmdd')
                   order by d_date asc)
           where rn = 1;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            CHDATESTR := '20010101';
        END;
    END;

    IF CHDATESTR IS NULL THEN
      BEGIN
        CHDATESTR := '20010101';
      END;
    END IF;
    return CHDATESTR;
  end;

BEGIN

  CHDATESTR := '******'; /*防止CHDATESTR为空*/
  BEGIN
    SELECT L_CHMONTH, L_CHDAY, C_ASSIGNTYPE
      INTO CHMONTH, CHDAY, TMPASSIGNTYPE
      FROM TQSSPECIALPRODUCT
     WHERE C_FUNDCODE = FUNDCODE
       AND C_PRODUCTTYPE = '0';
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      CHDATESTR := '20010101';
  END;

  IF INSTR('0,2', TMPASSIGNTYPE) > 0 THEN
    BEGIN
      ASSIGNTYPE := '0'; /*按月结转*/
    END;
  ELSIF INSTR('1,3,4', TMPASSIGNTYPE) > 0 THEN
    BEGIN
      ASSIGNTYPE := '1'; /*季度结转*/
    END;
  ELSE
    BEGIN
      ASSIGNTYPE := TMPASSIGNTYPE; /*表示非按月结转 非按季结转*/
    END;
  END IF;

  IF CHDATESTR <> '20010101' THEN
    BEGIN
      IF CHDAY >= 41 THEN  /* 按工作日*/
        BEGIN
          CHDATESTR := innergetchdatebyworkday(FUNDCODE, ASSIGNTYPE, CHMONTH, CHDAY);
        END;
      ELSE  /* 按自然日, CHDAY会存在为空的情况 */
        CHDATESTR := GETCHDATE(FUNDCODE, ASSIGNTYPE, CHMONTH, CHDAY);
      END IF;
    END;
  END IF;

  RETURN CHDATESTR;
END;

/

