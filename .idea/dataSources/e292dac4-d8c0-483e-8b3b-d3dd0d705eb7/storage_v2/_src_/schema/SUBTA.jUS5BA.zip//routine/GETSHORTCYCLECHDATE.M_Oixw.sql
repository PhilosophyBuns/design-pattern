create function GetShortCycleChDate(fundcode in varchar2,
                                               regDate  in varchar2,
                                               cfmDate  in varchar2,
                                               callType in varchar2 := '0')
  return varchar2 as
  m_cycletype  char(1);
  m_cyclestep  integer;
  m_calRegDate varchar2(8);
  m_calCfmDate varchar2(8);
  m_factstep   integer;
  m_chdate     date;
  m_isworkdate integer;
  m_oriSource  char(1);
  m_autoInc    integer;
  m_afmonth    integer;
  m_afYear     integer;
  T0flag       char(1);
  vsetupdate   varchar2(8);
  m_cyclerestdaytype   varchar2(1);
begin

  begin
    select c_cycletype, l_cyclestep, c_cyclerestdaytype
      into m_cycletype, m_cyclestep, m_cyclerestdaytype
      from tshortcyclefinance
     where c_fundcode = fundcode;
  exception
    when no_data_found then
      return - 1;
  end;

  T0flag := '0';
  select nvl(C_T0LIQUDIATE, '0'), to_char(d_setupdate, 'YYYYMMDD')
    into T0flag, vsetupdate
    from tfundinfo a
   where a.c_fundcode = fundcode;

    if regDate > vsetupdate  then
      m_orisource := '1';
      else
      m_orisource := '0';
    end if;


  /* 认购份额的到期日=基金成立日的次N个周期*/
  /* 申购份额的到期日=申购申请日的次N个周期*/
  /* 故认购份额直接用份额注册日期+N个周期即可，而申购要先计算出份额注册日期的上一个工作日*/
  if T0flag = '0' then
    if m_orisource = '0' then
      m_calRegDate := getrealdays(fundcode, '***', regDate, 0);
    else
      m_calRegDate := getrealdays(fundcode, '***', regDate, -1);
    end if;
  else
    -- 针对T+0 的流程，修改m_calRegDate, m_calCfmDate added by xiaym, 20130320
    m_calRegDate := getrealdays(fundcode, '***', regDate, 0);
  end if;
  m_calCfmDate := getrealdays(fundcode, '***', cfmDate, -1);
  if calltype = '0' then
    m_autoInc := 1;
  else
    m_autoInc := 0;
  end if;

  /*计算出跨度*/
  /*然后根据跨度计算出兑付日期*/
  if m_cycletype = '0' then
    m_factstep := trunc(trunc(months_between(to_date(m_calCfmDate,
                                                     'yyyymmdd'),
                                             to_date(m_calRegDate,
                                                     'yyyymmdd'))) /
                        m_cyclestep) + m_autoInc;
    m_afMonth  := to_number(substr(m_calRegDate, 5, 2)) +
                  m_factstep * m_cyclestep;
    m_afYear   := to_number(substr(m_calRegDate, 1, 4));
    while (m_afMonth > 12) loop
      m_afYear  := m_afYear + 1;
      m_afMonth := m_afMonth - 12;
    end loop;
    m_calRegDate := to_char(m_afYear) || lpad(to_char(m_afMonth), 2, '0') ||
                    substr(m_calRegDate, 7, 2);

    begin
      m_chdate := to_date(m_calRegDate, 'yyyymmdd');
    exception
      when others THEN
        m_afMonth := m_afMonth + 1;
        if m_afMonth > 12 THEN
          m_afYear  := m_afYear + 1;
          m_afMonth := m_afMonth - 12;
        end if;
        m_chdate := to_date(to_char(m_afYear) ||
                            lpad(to_char(m_afMonth), 2, '0') || '01',
                            'yyyymmdd');
    end;

  else
    m_factstep := trunc((to_date(m_calCfmDate, 'yyyymmdd') -
                        to_date(m_calRegDate, 'yyyymmdd')) / m_cyclestep) +
                  m_autoInc;
    m_chdate   := to_date(m_calRegDate, 'yyyymmdd') +
                  m_factstep * m_cyclestep;
  end if;

  begin
    select a.l_workflag
      into m_isworkdate
      from topenday a
     where d_date = m_chdate;

  exception when no_data_found then
    m_chdate := to_date('20991231','yyyymmdd');
    m_isworkdate := 1;
  end;

  if m_isworkdate = 0 then
    if m_cyclerestdaytype = 0 then
      m_chdate := to_date(getrealdays(fundcode,
                                      '***',
                                      to_char(m_chdate, 'yyyymmdd'),
                                      1),
                          'yyyymmdd');
    else
      m_chdate := to_date(getrealdays(fundcode,
                                      '***',
                                      to_char(m_chdate, 'yyyymmdd'),
                                      -1),
                          'yyyymmdd');
    end if;
  end if;

  return to_char(m_chdate, 'yyyymmdd');

end;

/

