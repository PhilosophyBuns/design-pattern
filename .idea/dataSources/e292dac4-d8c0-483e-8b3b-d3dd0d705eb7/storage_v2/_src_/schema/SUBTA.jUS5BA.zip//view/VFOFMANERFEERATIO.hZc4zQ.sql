create view VFOFMANERFEERATIO as
  select c_fundcode,f_manerfeeratio,d_cdate,
       last_value(d_enddate)over(partition by c_fundcode,  d_cdate
                                     order by d_enddate
                                      rows between unbounded preceding
                                               and unbounded following) d_enddate
from (select c_fundcode, f_manerfeeratio, d_cdate,
               nvl(lead(d_cdate)over(partition by c_fundcode
                                             order by d_cdate),
               to_date('20991231', 'yyyymmdd')) d_enddate
          from TFOFManerfeeratio )
/

