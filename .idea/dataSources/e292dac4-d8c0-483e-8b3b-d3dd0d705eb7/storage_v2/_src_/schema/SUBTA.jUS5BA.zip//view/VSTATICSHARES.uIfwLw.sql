create view VSTATICSHARES as
  select
   c_fundacco,
   c_fundcode,
   c_sharetype,
   c_agencyno,
   c_netno,
   sum(f_realshares) f_realshares,
   sum(f_frozenshares) f_frozenshares,
   sum(f_tradefreeze) f_tradefreeze,
   sum(f_lastshares) f_lastshares,
   min(c_bonustype) c_bonustype,
   max(d_lastmodify) d_lastmodify
from
TSTATICSHARES
group by c_fundacco,c_fundcode,c_sharetype,c_agencyno,c_netno
/

